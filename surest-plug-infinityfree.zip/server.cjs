var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// server.ts
var import_dotenv2 = __toESM(require("dotenv"), 1);
var import_express = __toESM(require("express"), 1);
var import_path3 = __toESM(require("path"), 1);
var import_fs3 = __toESM(require("fs"), 1);

// src/server/smmService.ts
var import_dotenv = __toESM(require("dotenv"), 1);
try {
  import_dotenv.default.config();
} catch (e) {
}
var FOLLOWSPANEL_API_URL = "https://followspanel.com/api/v2";
var FOLLOWSPANEL_SERVICES_URL = "https://followspanel.com/services";
var servicesCache = null;
var CACHE_TTL_MS = 10 * 60 * 1e3;
function getFollowSPanelConfigStatus() {
  const key = getApiKey();
  return {
    configured: Boolean(key),
    length: key ? key.length : 0,
    endpoint: FOLLOWSPANEL_API_URL
  };
}
function getApiKey() {
  const rawKey = process.env.FOLLOWSPANEL_API_KEY || process.env.FOLLOWS_PANEL_API_KEY || process.env.FOLLOWSPANEL_KEY || process.env.FOLLOWS_PANEL_KEY || "";
  let cleanKey = rawKey.trim().replace(/^[\uFEFF\xA0]+|[\uFEFF\xA0]+$/g, "").replace(/[\r\n\t]/g, "");
  if (cleanKey.startsWith('"') && cleanKey.endsWith('"') && cleanKey.length >= 2 || cleanKey.startsWith("'") && cleanKey.endsWith("'") && cleanKey.length >= 2) {
    cleanKey = cleanKey.slice(1, -1).trim();
  }
  const isPlaceholder = cleanKey.toLowerCase() === "followspanel_api_key" || cleanKey.toLowerCase() === "undefined" || cleanKey.toLowerCase() === "null" || cleanKey.toLowerCase() === "my_api_key" || cleanKey.toLowerCase() === "your_api_key_here";
  if (!cleanKey || isPlaceholder) {
    console.warn(
      `[FollowSPanel Diagnostic] FOLLOWSPANEL_API_KEY configured: false (missing or placeholder in environment)`
    );
    return "";
  }
  return cleanKey;
}
async function callFollowSPanelApi(params, isAdminQuery = false) {
  const apiKey = getApiKey();
  if (!apiKey) {
    console.warn(
      `[FollowSPanel Diagnostic] Request aborted for action "${params.action}": FOLLOWSPANEL_API_KEY configured: false (missing or invalid).`
    );
    return {
      success: false,
      code: "MISSING_API_KEY",
      error: isAdminQuery ? "FOLLOWSPANEL_API_KEY is not configured on the server. Please configure your FollowSPanel API key in server environment variables / secrets." : "Provider authentication is required for this action. Please contact administrator."
    };
  }
  console.log(`[FollowSPanel Request] action: "${params.action}", FOLLOWSPANEL_API_KEY configured: true, length: ${apiKey.length}`);
  const postParams = new URLSearchParams();
  postParams.append("key", apiKey);
  for (const [k, v] of Object.entries(params)) {
    postParams.append(k, String(v));
  }
  const startTime = Date.now();
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 2e4);
    const response = await fetch(FOLLOWSPANEL_API_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
        "User-Agent": "SurestPlug-Server/1.0"
      },
      body: postParams.toString(),
      signal: controller.signal
    });
    clearTimeout(timeoutId);
    const latency = Date.now() - startTime;
    if (response.status !== 200) {
      let errDetail = `HTTP ${response.status} (${response.statusText})`;
      try {
        const errText = await response.text();
        const trimmed2 = (errText || "").trim();
        if (trimmed2.startsWith("<") || trimmed2.toLowerCase().startsWith("<!doctype")) {
          errDetail = `Provider returned HTML error page (HTTP ${response.status})`;
        } else {
          try {
            const errJson = JSON.parse(errText);
            if (errJson && errJson.error) {
              errDetail = String(errJson.error);
            }
          } catch {
            if (errText && errText.length < 200) {
              errDetail = errText.trim();
            }
          }
        }
      } catch {
      }
      if (response.status === 401 || errDetail.toLowerCase().includes("api key") || errDetail.toLowerCase().includes("invalid key")) {
        const adminAuthError = "FollowSPanel authentication failed: The configured FOLLOWSPANEL_API_KEY was rejected by followspanel.com (Invalid API key). Please generate or copy your active API key from your FollowSPanel account (https://followspanel.com/account) and update the FOLLOWSPANEL_API_KEY secret.";
        return {
          success: false,
          code: "AUTH_FAILED",
          error: isAdminQuery ? adminAuthError : "Social media boosting services are temporarily unavailable."
        };
      }
      return {
        success: false,
        code: response.status,
        error: isAdminQuery ? `FollowSPanel API returned HTTP ${response.status}: ${errDetail}` : "Provider returned an error. Please try again later."
      };
    }
    const text = await response.text();
    const trimmed = (text || "").trim();
    if (trimmed.startsWith("<") || trimmed.toLowerCase().startsWith("<!doctype") || trimmed.includes("<html")) {
      console.warn(`[FollowSPanel API] HTML response received (HTTP 200) in ${latency}ms for action: ${params.action}`);
      return {
        success: false,
        code: "HTML_RESPONSE",
        error: isAdminQuery ? "FollowSPanel API returned an HTML webpage instead of JSON. The provider endpoint (https://followspanel.com/api/v2) may be under maintenance, redirecting, or blocked." : "Social media boosting provider returned an invalid response format. Please try again later."
      };
    }
    let json = null;
    try {
      json = JSON.parse(text);
    } catch {
      console.warn(`[FollowSPanel API] Non-JSON response (HTTP 200) in ${latency}ms for action: ${params.action}`);
      return {
        success: false,
        code: "INVALID_JSON",
        error: isAdminQuery ? `Non-JSON response from FollowSPanel (HTTP 200): ${text.slice(0, 150)}` : "Invalid response received from provider."
      };
    }
    if (json && typeof json === "object" && "error" in json && json.error) {
      const errStr = String(json.error);
      if (errStr.toLowerCase().includes("api key") || errStr.toLowerCase().includes("invalid key")) {
        const adminAuthError = "FollowSPanel authentication failed: The configured FOLLOWSPANEL_API_KEY was rejected by followspanel.com (Invalid API key). Please generate or copy your active API key from your FollowSPanel account (https://followspanel.com/account) and update the FOLLOWSPANEL_API_KEY secret.";
        return {
          success: false,
          code: "AUTH_FAILED",
          error: isAdminQuery ? adminAuthError : "Social media boosting services are temporarily unavailable."
        };
      }
      return {
        success: false,
        code: "PROVIDER_ERROR",
        error: errStr
      };
    }
    return {
      success: true,
      data: json
    };
  } catch (err) {
    const isTimeout = err.name === "AbortError";
    const msg = isTimeout ? "FollowSPanel API request timed out after 20 seconds." : err?.message || "Network unreachable";
    console.error(`[FollowSPanel API] Request failed for action: ${params.action} - ${msg}`);
    return {
      success: false,
      code: isTimeout ? "TIMEOUT" : "NETWORK_ERROR",
      error: isAdminQuery ? `Connection error: ${msg}` : "Could not reach boosting provider. Please check your network connection."
    };
  }
}
async function fetchFollowSPanelPublicCatalog() {
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 15e3);
    const res = await fetch(FOLLOWSPANEL_SERVICES_URL, {
      headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"
      },
      signal: controller.signal
    });
    clearTimeout(timeoutId);
    if (!res.ok) {
      throw new Error(`Failed to fetch FollowSPanel services page: HTTP ${res.status}`);
    }
    const html = await res.text();
    const rows = html.split("<tr").slice(1);
    const services = [];
    let currentCategory = "General";
    for (const r of rows) {
      if (r.includes("data-filter-table-category-id") && r.includes('colspan="100%"')) {
        const m = r.match(/<strong>([\s\S]*?)<\/strong>/);
        if (m) {
          currentCategory = m[1].replace(/<[^>]+>/g, "").trim();
        }
      } else if (r.includes("data-filter-table-service-id=")) {
        const idM = r.match(/data-filter-table-service-id="(\d+)"/);
        const nameM = r.match(/class="service-name"[^>]*>([\s\S]*?)<\/td>/);
        if (idM && nameM) {
          const id = parseInt(idM[1], 10);
          const name = nameM[1].replace(/<[^>]+>/g, "").trim();
          const parts = r.split("<td").slice(1).map(
            (p) => p.replace(/[\s\S]*?>/, "").replace(/<\/td>[\s\S]*/, "").replace(/<[^>]+>/g, "").trim()
          );
          let rate = "0";
          let min = 10;
          let max = 1e5;
          if (parts.length >= 5) {
            rate = parts[2].replace(/[^0-9.]/g, "") || "0";
            min = parseInt(parts[3].replace(/[^0-9]/g, ""), 10) || 10;
            max = parseInt(parts[4].replace(/[^0-9]/g, ""), 10) || 1e5;
          }
          services.push({
            service: id,
            name,
            type: "Default",
            category: currentCategory,
            rate,
            min,
            max
          });
        }
      }
    }
    if (services.length > 0) {
      return services;
    }
  } catch (err) {
    console.error("Error in fetchFollowSPanelPublicCatalog:", err?.message);
  }
  return [];
}
async function testFollowSPanelConnection() {
  const startTime = Date.now();
  const apiKey = getApiKey();
  if (!apiKey) {
    return {
      success: false,
      code: "MISSING_API_KEY",
      data: {
        connected: false,
        provider: "FollowSPanel",
        latency_ms: 0,
        error: "FOLLOWSPANEL_API_KEY environment variable is not configured on the server.",
        details: "Please set your FollowSPanel API key in the server environment secrets."
      },
      error: "FOLLOWSPANEL_API_KEY environment variable is not configured on the server."
    };
  }
  const res = await callFollowSPanelApi({ action: "balance" }, true);
  const latency = Date.now() - startTime;
  if (!res.success || !res.data) {
    return {
      success: false,
      data: {
        connected: false,
        provider: "FollowSPanel",
        latency_ms: latency,
        error: res.error || "Failed to authenticate with FollowSPanel API.",
        details: res.code ? `Error Code: ${res.code}` : void 0
      },
      error: res.error || "Failed to authenticate with FollowSPanel API."
    };
  }
  let balanceVal = void 0;
  if (res.data.balance !== void 0 && res.data.balance !== null) {
    balanceVal = String(res.data.balance).trim();
  } else if (res.data.funds !== void 0 && res.data.funds !== null) {
    balanceVal = String(res.data.funds).trim();
  }
  return {
    success: true,
    data: {
      connected: true,
      provider: "FollowSPanel",
      balance: balanceVal,
      currency: String(res.data.currency || "NGN").toUpperCase(),
      latency_ms: latency
    }
  };
}
async function getFollowSPanelServices() {
  const now = Date.now();
  if (servicesCache && now - servicesCache.timestamp < CACHE_TTL_MS && servicesCache.data.length > 0) {
    return {
      success: true,
      data: servicesCache.data
    };
  }
  const apiRes = await callFollowSPanelApi({ action: "services" }, false);
  if (apiRes.success && Array.isArray(apiRes.data) && apiRes.data.length > 0) {
    const formattedServices = apiRes.data.map((item) => ({
      service: isNaN(Number(item.service)) ? String(item.service ?? "") : Number(item.service),
      name: String(item.name || ""),
      type: String(item.type || "Default"),
      category: String(item.category || "General"),
      rate: String(item.rate || "0"),
      min: Number(item.min) || 10,
      max: Number(item.max) || 1e5,
      refill: Boolean(item.refill),
      cancel: Boolean(item.cancel),
      dripfeed: Boolean(item.dripfeed)
    }));
    servicesCache = {
      timestamp: now,
      data: formattedServices
    };
    return {
      success: true,
      data: formattedServices
    };
  }
  const publicServices = await fetchFollowSPanelPublicCatalog();
  if (publicServices.length > 0) {
    servicesCache = {
      timestamp: now,
      data: publicServices
    };
    return {
      success: true,
      data: publicServices
    };
  }
  if (servicesCache && servicesCache.data.length > 0) {
    return {
      success: true,
      data: servicesCache.data
    };
  }
  return {
    success: false,
    error: "Failed to retrieve social media boosting services from FollowSPanel."
  };
}
async function createFollowSPanelOrder(serviceId, link, quantity) {
  if (!link || !link.trim() || link.trim().length < 3) {
    return {
      success: false,
      error: "Please provide a valid target URL or social media username."
    };
  }
  const parsedQty = Number(quantity);
  if (isNaN(parsedQty) || parsedQty <= 0) {
    return {
      success: false,
      error: "Please provide a valid quantity."
    };
  }
  if (!serviceId) {
    return {
      success: false,
      error: "Please select a valid boosting service."
    };
  }
  const res = await callFollowSPanelApi({
    action: "add",
    service: Number(serviceId),
    link: link.trim(),
    quantity: parsedQty
  }, true);
  if (!res.success) {
    return {
      success: false,
      error: res.error || "Failed to dispatch order with provider. Please verify your details."
    };
  }
  if (res.data && res.data.order) {
    return {
      success: true,
      data: { order_id: Number(res.data.order) }
    };
  }
  return {
    success: false,
    error: res.data?.error ? String(res.data.error) : "Failed to dispatch order with provider."
  };
}
async function getFollowSPanelOrderStatus(orderId) {
  if (!orderId) {
    return {
      success: false,
      error: "Order ID is required."
    };
  }
  const res = await callFollowSPanelApi({
    action: "status",
    order: orderId
  }, true);
  if (!res.success) {
    return {
      success: false,
      error: res.error || "Unable to fetch status from provider."
    };
  }
  return {
    success: true,
    data: res.data
  };
}
async function getFollowSPanelMultipleOrderStatus(orderIds) {
  if (!orderIds || orderIds.length === 0) {
    return {
      success: false,
      error: "Order IDs are required."
    };
  }
  const res = await callFollowSPanelApi({
    action: "status",
    orders: orderIds.join(",")
  }, true);
  if (!res.success) {
    return {
      success: false,
      error: res.error || "Unable to fetch status from provider."
    };
  }
  return {
    success: true,
    data: res.data
  };
}
async function getFollowSPanelBalance() {
  const res = await callFollowSPanelApi({ action: "balance" }, true);
  if (!res.success || !res.data) {
    return {
      success: false,
      code: res.code,
      error: res.error || "Unable to retrieve FollowSPanel balance."
    };
  }
  let balanceVal = null;
  if (res.data.balance !== void 0 && res.data.balance !== null) {
    balanceVal = String(res.data.balance).trim();
  } else if (res.data.funds !== void 0 && res.data.funds !== null) {
    balanceVal = String(res.data.funds).trim();
  }
  if (balanceVal === null || balanceVal === "" || isNaN(Number(balanceVal))) {
    return {
      success: false,
      code: "INVALID_BALANCE_FORMAT",
      error: "FollowSPanel API did not return a valid numeric balance."
    };
  }
  return {
    success: true,
    data: {
      balance: balanceVal,
      currency: String(res.data.currency || "NGN").toUpperCase(),
      connected: true,
      status: "Connected"
    }
  };
}

// src/server/cartlogsService.ts
var import_crypto = __toESM(require("crypto"), 1);

// src/lib/pricing.ts
function calculateSellingPrice(supplierPrice) {
  const price = Number(supplierPrice);
  if (isNaN(price) || price <= 0) {
    return 0;
  }
  if (price < 1e4) {
    return Math.round(price * 2);
  } else if (price <= 1e5) {
    return Math.round(price + 5e3);
  } else if (price <= 5e5) {
    return Math.round(price + 15e3);
  } else {
    return Math.round(price + 25e3);
  }
}

// src/server/cartlogsService.ts
var CARTLOGS_API_BASE_URL = "https://api.cartlogs.com/api/v1";
function isBoostingService(title, categoryName, type) {
  const combined = `${title || ""} ${categoryName || ""} ${type || ""}`.toLowerCase();
  const boostingKeywords = [
    "boost",
    "boosting",
    "smm",
    "follower boost",
    "likes boost",
    "views boost",
    "custom comments",
    "retweets",
    "upvotes",
    "reactions",
    "drip feed",
    "dripfeed",
    "subscribers boost",
    "members boost",
    "watch hours",
    "live stream viewers"
  ];
  return boostingKeywords.some((keyword) => combined.includes(keyword));
}
async function callCartlogsApi(endpoint, method = "GET", body, customHeaders = {}, isAdminQuery = false) {
  const apiKey = process.env.CARTLOGS_API_KEY;
  if (!apiKey || !apiKey.trim()) {
    return {
      success: false,
      error: isAdminQuery ? "CARTLOGS_API_KEY environment variable is not configured on the server. Please add it to your server environment or .env file." : "Account logs and services are temporarily unavailable. Please try again later."
    };
  }
  const cleanEndpoint = endpoint.startsWith("/") ? endpoint : `/${endpoint}`;
  const url = `${CARTLOGS_API_BASE_URL}${cleanEndpoint}`;
  const headers = {
    "Authorization": `Bearer ${apiKey.trim()}`,
    "Accept": "application/json",
    "User-Agent": "SurestPlug-Server/1.0",
    ...customHeaders
  };
  if (body && (method === "POST" || method === "PUT")) {
    headers["Content-Type"] = "application/json";
  }
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 2e4);
    const response = await fetch(url, {
      method,
      headers,
      body: body ? JSON.stringify(body) : void 0,
      signal: controller.signal
    });
    clearTimeout(timeoutId);
    const text = await response.text();
    let json = null;
    try {
      json = JSON.parse(text);
    } catch {
      if (!response.ok) {
        return {
          success: false,
          code: response.status,
          error: isAdminQuery ? `Cartlogs API returned HTTP ${response.status}: ${response.statusText}` : "Service is temporarily unavailable. Please try again later."
        };
      }
    }
    if (!response.ok) {
      let friendlyError = "Product is currently unavailable. Please try again later.";
      let adminDetail = json?.detail || json?.message || json?.error || `HTTP error ${response.status}`;
      if (response.status === 401) {
        friendlyError = "Service configuration issue. Please contact support.";
        adminDetail = "401 INVALID_API_KEY: Authentication failed. Please check CARTLOGS_API_KEY.";
      } else if (response.status === 402) {
        friendlyError = "Product is currently out of stock or unavailable.";
        adminDetail = "402 INSUFFICIENT_FUNDS / INSUFFICIENT_INVENTORY on Cartlogs supplier account.";
      } else if (response.status === 404) {
        friendlyError = "The requested account is no longer available.";
        adminDetail = "404 INVALID_PRODUCT_ID: Product was not found on Cartlogs catalog.";
      } else if (response.status === 409) {
        friendlyError = "Duplicate order request detected. Please check your Orders page.";
        adminDetail = "409 DUPLICATE_IDEMPOTENCY_KEY: This idempotency key was already used.";
      } else if (response.status === 429) {
        friendlyError = "High demand detected. Please wait a few seconds and try again.";
        adminDetail = "429 RATE_LIMIT_EXCEEDED: Cartlogs API rate limit reached.";
      } else if (response.status >= 500) {
        friendlyError = "Supplier service is undergoing maintenance. Please try again soon.";
        adminDetail = `500 SERVER_ERROR from Cartlogs: ${adminDetail}`;
      }
      return {
        success: false,
        code: response.status,
        error: isAdminQuery ? String(adminDetail) : friendlyError
      };
    }
    return {
      success: true,
      data: json
    };
  } catch (err) {
    const isTimeout = err.name === "AbortError";
    return {
      success: false,
      error: isTimeout ? isAdminQuery ? "Cartlogs API request timed out after 20 seconds." : "Request timed out. Please try again." : isAdminQuery ? `Cartlogs connection error: ${err.message}` : "Account service is temporarily unavailable. Please try again later."
    };
  }
}
async function testCartlogsConnection() {
  const startTime = Date.now();
  const catRes = await callCartlogsApi("/categories/", "GET", void 0, {}, true);
  const latency = Date.now() - startTime;
  if (!catRes.success) {
    return {
      success: false,
      data: {
        connected: false,
        provider: "Cartlogs",
        latency_ms: latency,
        categories_count: 0,
        products_count: 0,
        otp_supported: false,
        error: catRes.error || "Failed to authenticate with Cartlogs API."
      },
      error: catRes.error || "Failed to authenticate with Cartlogs API."
    };
  }
  const rawCats = Array.isArray(catRes.data) ? catRes.data : catRes.data?.results || catRes.data?.data || [];
  let productsCount = 0;
  const prodRes = await callCartlogsApi("/products/", "GET", void 0, {}, true);
  if (prodRes.success) {
    const rawProds = Array.isArray(prodRes.data) ? prodRes.data : prodRes.data?.results || prodRes.data?.data || [];
    productsCount = rawProds.length;
  }
  let balance = void 0;
  let currency = "NGN";
  try {
    const balRes = await callCartlogsApi("/balance/", "GET", void 0, {}, true);
    if (balRes.success && balRes.data) {
      balance = balRes.data.balance || balRes.data.amount || balRes.data.wallet;
      currency = balRes.data.currency || "NGN";
    }
  } catch {
  }
  const otpCheck = await inspectCartlogsOtpCapabilities();
  return {
    success: true,
    data: {
      connected: true,
      provider: "Cartlogs",
      latency_ms: latency,
      categories_count: rawCats.length,
      products_count: productsCount,
      balance,
      currency,
      otp_supported: otpCheck.supported
    }
  };
}
async function getCartlogsCategories(isAdmin = false) {
  const res = await callCartlogsApi("/categories/", "GET", void 0, {}, isAdmin);
  if (!res.success) {
    return {
      success: false,
      error: res.error || (isAdmin ? "Failed to fetch categories from Cartlogs." : "Categories are temporarily unavailable.")
    };
  }
  const rawList = Array.isArray(res.data) ? res.data : res.data?.results || res.data?.data || [];
  const sanitized = rawList.filter((cat) => {
    const name = cat.name || cat.title || "";
    return !isBoostingService("", name);
  }).map((cat, idx) => {
    const id = String(cat.id || cat.pk || idx + 1);
    const name = cat.name || cat.title || `Category ${id}`;
    const slug = cat.slug || name.toLowerCase().replace(/[^a-z0-9]+/g, "-");
    const count = Number(cat.products_count || cat.count || 0);
    return {
      id,
      name,
      slug,
      product_count: count
    };
  });
  return {
    success: true,
    data: sanitized
  };
}
async function getCartlogsProducts(categoryFilter, isAdmin = false) {
  let endpoint = "/products/";
  if (categoryFilter && categoryFilter !== "all") {
    endpoint += `?category=${encodeURIComponent(categoryFilter)}`;
  }
  const res = await callCartlogsApi(endpoint, "GET", void 0, {}, isAdmin);
  if (!res.success) {
    return {
      success: false,
      error: res.error || (isAdmin ? "Failed to fetch products from Cartlogs." : "Products are temporarily unavailable.")
    };
  }
  const rawList = Array.isArray(res.data) ? res.data : res.data?.results || res.data?.data || [];
  const sanitizedProducts = [];
  for (const raw of rawList) {
    const title = raw.title || raw.name || "Social Media Account";
    let catName = "Social Accounts";
    if (typeof raw.category === "string") {
      catName = raw.category;
    } else if (raw.category && typeof raw.category === "object") {
      catName = raw.category.name || raw.category.title || "Social Accounts";
    }
    if (isBoostingService(title, catName, raw.service_type || raw.type)) {
      continue;
    }
    const rawCost = typeof raw.price === "number" ? raw.price : typeof raw.cost === "number" ? raw.cost : parseFloat(String(raw.price || raw.cost || "0"));
    const supplierCost = Math.max(0, isNaN(rawCost) ? 0 : rawCost);
    const sellingPrice = calculateSellingPrice(supplierCost);
    const stockVal = typeof raw.stock === "number" ? raw.stock : typeof raw.quantity === "number" ? raw.quantity : parseInt(String(raw.stock || raw.quantity || "0"), 10);
    const stock = isNaN(stockVal) ? 0 : stockVal;
    const inStock = raw.in_stock !== void 0 ? Boolean(raw.in_stock) : stock > 0;
    const followers = raw.followers_count || raw.followers;
    const following = raw.following_count || raw.following;
    const age = raw.account_age || raw.age;
    const isVerified = raw.is_verified || raw.verified === true || raw.verified === "verified";
    let features = [];
    if (Array.isArray(raw.features)) {
      features = raw.features.map(String);
    } else if (typeof raw.features === "string" && raw.features.trim()) {
      features = raw.features.split(",").map((f) => f.trim()).filter(Boolean);
    } else {
      if (isVerified) features.push("Verified Account Badge");
      if (age) features.push(`Aged Account (${age})`);
      if (followers) features.push(`${followers.toLocaleString?.() || followers} Followers`);
      if (raw.country) features.push(`Region: ${raw.country}`);
      features.push("Full Email & Login Access");
      features.push("Instant Delivery");
    }
    sanitizedProducts.push({
      id: String(raw.id || raw.pk || raw.product_id || Math.random().toString(36).substr(2, 9)),
      title,
      category: catName,
      description: raw.description || raw.details || `Authentic ${catName} account ready for business marketing and instant outreach.`,
      supplier_price: supplierCost,
      price: sellingPrice,
      stock,
      in_stock: inStock,
      followers_count: followers,
      following_count: following,
      account_age: age,
      verification_status: isVerified ? "verified" : "unverified",
      country: raw.country,
      gender: raw.gender,
      features
    });
  }
  return {
    success: true,
    data: sanitizedProducts
  };
}
async function createCartlogsOrder(productId, quantity = 1, surestPlugOrderId, idempotencyKey, isAdmin = false) {
  const uniqueKey = idempotencyKey || `sp_cartlogs_${surestPlugOrderId}_${Date.now()}`;
  const payload = {
    items: [
      {
        product_id: productId,
        quantity: quantity || 1
      }
    ],
    metadata: {
      customer_reference: surestPlugOrderId
    }
  };
  const headers = {
    "Idempotency-Key": uniqueKey
  };
  const res = await callCartlogsApi("/orders/", "POST", payload, headers, isAdmin);
  if (!res.success) {
    return {
      success: false,
      code: res.code,
      error: res.error || (isAdmin ? "Cartlogs order submission failed." : "Account is currently unavailable. Please try again.")
    };
  }
  const orderData = res.data;
  const cartlogsOrderId = orderData?.id || orderData?.order_id || orderData?.pk || "N/A";
  const status = orderData?.status || "completed";
  let credentials = void 0;
  const rawCreds = orderData?.credentials || orderData?.items?.[0]?.credentials || orderData?.item?.credentials || orderData?.data;
  if (rawCreds) {
    if (typeof rawCreds === "object") {
      credentials = {
        username: rawCreds.username || rawCreds.user || rawCreds.login,
        password: rawCreds.password || rawCreds.pass,
        email: rawCreds.email || rawCreds.mail,
        email_password: rawCreds.email_password || rawCreds.mail_password,
        two_factor_key: rawCreds.two_factor_key || rawCreds["2fa_key"] || rawCreds.two_fa,
        two_factor_code: rawCreds.two_factor_code || rawCreds["2fa_code"],
        recovery_email: rawCreds.recovery_email,
        additional_info: rawCreds.additional_info || rawCreds.notes || rawCreds.info,
        raw_details: rawCreds.raw || rawCreds.text
      };
    } else if (typeof rawCreds === "string") {
      credentials = {
        raw_details: rawCreds
      };
    }
  }
  return {
    success: true,
    data: {
      cartlogs_order_id: cartlogsOrderId,
      status,
      credentials
    }
  };
}
async function getCartlogsOrderStatus(orderId, isAdmin = false) {
  if (!orderId || orderId === "N/A") {
    return { success: false, error: "Order ID is required." };
  }
  const res = await callCartlogsApi(`/orders/${orderId}/`, "GET", void 0, {}, isAdmin);
  return res;
}
function verifyCartlogsWebhookSignature(rawBody, signatureHeader, secret) {
  const webhookSecret = secret || process.env.CARTLOGS_WEBHOOK_SECRET;
  if (!webhookSecret || !webhookSecret.trim()) {
    return true;
  }
  if (!signatureHeader) {
    return false;
  }
  try {
    const computed = import_crypto.default.createHmac("sha256", webhookSecret.trim()).update(rawBody).digest("hex");
    const cleanSignature = signatureHeader.replace(/^sha256=/, "").trim();
    return import_crypto.default.timingSafeEqual(
      Buffer.from(computed, "utf-8"),
      Buffer.from(cleanSignature, "utf-8")
    );
  } catch {
    return false;
  }
}
async function inspectCartlogsOtpCapabilities() {
  try {
    const catRes = await callCartlogsApi("/categories/", "GET", void 0, {}, true);
    if (!catRes.success) {
      return {
        supported: false,
        categories: [],
        message: "Cartlogs API is not reachable or CARTLOGS_API_KEY is not set."
      };
    }
    const categoriesList = Array.isArray(catRes.data) ? catRes.data : catRes.data?.results || catRes.data?.data || [];
    const catNames = categoriesList.map((c) => (c.name || c.title || "").toLowerCase());
    const otpKeywords = ["otp", "phone", "virtual number", "sms verification", "phone verification", "sim"];
    const matchingCats = catNames.filter((name) => otpKeywords.some((kw) => name.includes(kw)));
    if (matchingCats.length > 0) {
      return {
        supported: true,
        categories: matchingCats,
        message: `Cartlogs provides phone/OTP verification in categories: ${matchingCats.join(", ")}`
      };
    }
    return {
      supported: false,
      categories: [],
      message: "Cartlogs does not currently expose international phone/OTP verification numbers in its documented categories."
    };
  } catch {
    return {
      supported: false,
      categories: [],
      message: "Unable to inspect Cartlogs OTP capabilities."
    };
  }
}

// src/server/paystackService.ts
var import_crypto2 = __toESM(require("crypto"), 1);
var PAYSTACK_API_BASE_URL = "https://api.paystack.co";
var DEFAULT_TEST_PUBLIC_KEY = "pk_test_c6a989fa162d6563a2e53015cd6cf15570f68d8f";
var processedReferences = /* @__PURE__ */ new Map();
var inFlightVerifications = /* @__PURE__ */ new Map();
function generatePaystackReference(userId) {
  const timestamp = Date.now();
  const randomHex = import_crypto2.default.randomBytes(4).toString("hex").toUpperCase();
  const userPrefix = userId ? `U${userId}` : "CUST";
  return `SP-PSTK-${userPrefix}-${timestamp}-${randomHex}`;
}
function isReferenceAlreadyProcessed(reference) {
  return processedReferences.has(reference.trim());
}
function markReferenceAsProcessed(reference, userId, amount, status = "success") {
  processedReferences.set(reference.trim(), {
    userId,
    amount,
    verifiedAt: (/* @__PURE__ */ new Date()).toISOString(),
    status
  });
}
async function initializePaystackTransaction(params) {
  try {
    const { amount, email, userId, name, callbackUrl, metadata = {} } = params;
    const numericAmount = Number(amount);
    if (!amount || isNaN(numericAmount) || numericAmount <= 0) {
      return { success: false, error: "Please enter a valid deposit amount." };
    }
    if (numericAmount < 1e3) {
      return { success: false, error: "Minimum funding amount is \u20A61,000." };
    }
    if (!email || !email.includes("@")) {
      return { success: false, error: "A valid email address is required for payment." };
    }
    const amountInNaira = Math.round(numericAmount);
    const amountInKobo = amountInNaira * 100;
    const reference = generatePaystackReference(userId);
    const publicKey = process.env.VITE_PAYSTACK_PUBLIC_KEY || DEFAULT_TEST_PUBLIC_KEY;
    const secretKey = process.env.PAYSTACK_SECRET_KEY || "";
    const enrichedMetadata = {
      ...metadata,
      userId: userId || "anonymous",
      userEmail: email,
      userName: name || "",
      purpose: "wallet_funding",
      site: "Surest Plug",
      reference,
      custom_fields: [
        {
          display_name: "Customer Name",
          variable_name: "customer_name",
          value: name || "Valued Customer"
        },
        {
          display_name: "Funding Purpose",
          variable_name: "purpose",
          value: "Surest Plug Wallet Deposit"
        },
        {
          display_name: "User ID",
          variable_name: "user_id",
          value: String(userId || "")
        }
      ]
    };
    if (secretKey && secretKey.trim().length > 0) {
      try {
        const response = await fetch(`${PAYSTACK_API_BASE_URL}/transaction/initialize`, {
          method: "POST",
          headers: {
            "Authorization": `Bearer ${secretKey.trim()}`,
            "Content-Type": "application/json"
          },
          body: JSON.stringify({
            email: email.trim().toLowerCase(),
            amount: amountInKobo,
            reference,
            callback_url: callbackUrl,
            metadata: enrichedMetadata
          })
        });
        const resData = await response.json();
        if (resData && resData.status && resData.data) {
          return {
            success: true,
            data: {
              reference: resData.data.reference || reference,
              amountInKobo,
              amountInNaira,
              publicKey,
              authorizationUrl: resData.data.authorization_url,
              accessCode: resData.data.access_code
            }
          };
        }
      } catch (apiErr) {
        console.warn("[Paystack Init] Direct API init error, falling back to client popup params:", apiErr);
      }
    }
    return {
      success: true,
      data: {
        reference,
        amountInKobo,
        amountInNaira,
        publicKey
      }
    };
  } catch (error) {
    return {
      success: false,
      error: error.message || "Failed to initialize Paystack transaction."
    };
  }
}
async function verifyPaystackTransaction(reference, expectedAmountInNaira, userId, userEmail) {
  const cleanRef = (reference || "").trim();
  if (!cleanRef) {
    return { success: false, verified: false, error: "Transaction reference is required." };
  }
  if (isReferenceAlreadyProcessed(cleanRef)) {
    const cached = processedReferences.get(cleanRef);
    return {
      success: true,
      verified: true,
      alreadyProcessed: true,
      reference: cleanRef,
      amount: cached?.amount || expectedAmountInNaira,
      userId: cached?.userId || userId,
      customerEmail: cached?.customerEmail || userEmail,
      gatewayResponse: "Already Processed"
    };
  }
  if (inFlightVerifications.has(cleanRef)) {
    return inFlightVerifications.get(cleanRef);
  }
  const verificationPromise = (async () => {
    try {
      const secretKey = process.env.PAYSTACK_SECRET_KEY || "";
      if (secretKey && secretKey.trim().length > 0) {
        const response = await fetch(`${PAYSTACK_API_BASE_URL}/transaction/verify/${encodeURIComponent(cleanRef)}`, {
          method: "GET",
          headers: {
            "Authorization": `Bearer ${secretKey.trim()}`,
            "Content-Type": "application/json"
          }
        });
        const resData = await response.json();
        if (!response.ok || !resData || !resData.status) {
          return {
            success: false,
            verified: false,
            reference: cleanRef,
            error: resData?.message || "Transaction verification failed on Paystack."
          };
        }
        const txData = resData.data;
        if (txData.status !== "success") {
          return {
            success: false,
            verified: false,
            reference: cleanRef,
            gatewayResponse: txData.gateway_response,
            error: `Payment was not completed (Status: ${txData.status || "abandoned"}).`
          };
        }
        if (txData.currency && txData.currency !== "NGN") {
          return {
            success: false,
            verified: false,
            reference: cleanRef,
            error: `Unexpected currency ${txData.currency}. Only NGN is supported.`
          };
        }
        const paidKobo = Number(txData.amount);
        const paidNaira = paidKobo / 100;
        if (paidNaira < 1e3) {
          return {
            success: false,
            verified: false,
            reference: cleanRef,
            amount: paidNaira,
            amountInKobo: paidKobo,
            error: "Minimum funding amount is \u20A61,000."
          };
        }
        if (expectedAmountInNaira && expectedAmountInNaira > 0) {
          const expectedKobo = Math.round(expectedAmountInNaira * 100);
          if (paidKobo < expectedKobo) {
            return {
              success: false,
              verified: false,
              reference: cleanRef,
              amount: paidNaira,
              amountInKobo: paidKobo,
              error: `Paid amount (\u20A6${paidNaira}) is less than expected deposit amount (\u20A6${expectedAmountInNaira}).`
            };
          }
        }
        const verifiedEmail = txData.customer?.email || userEmail;
        const verifiedUserId = userId || txData.metadata?.userId || txData.metadata?.user_id || "unknown";
        markReferenceAsProcessed(cleanRef, verifiedUserId, paidNaira, "success");
        if (processedReferences.has(cleanRef)) {
          const entry = processedReferences.get(cleanRef);
          if (entry) entry.customerEmail = verifiedEmail;
        }
        return {
          success: true,
          verified: true,
          alreadyProcessed: false,
          reference: cleanRef,
          amount: paidNaira,
          amountInKobo: paidKobo,
          currency: txData.currency || "NGN",
          paidAt: txData.paid_at || (/* @__PURE__ */ new Date()).toISOString(),
          customerEmail: verifiedEmail,
          customerName: txData.customer?.first_name ? `${txData.customer.first_name} ${txData.customer.last_name || ""}`.trim() : void 0,
          userId: verifiedUserId,
          gatewayResponse: txData.gateway_response || "Successful"
        };
      } else {
        console.log(`[Paystack Service] Verifying reference format: ${cleanRef}`);
        const verifiedNaira = expectedAmountInNaira && expectedAmountInNaira > 0 ? expectedAmountInNaira : 1e3;
        markReferenceAsProcessed(cleanRef, userId || "user", verifiedNaira, "success");
        if (processedReferences.has(cleanRef)) {
          const entry = processedReferences.get(cleanRef);
          if (entry) entry.customerEmail = userEmail;
        }
        return {
          success: true,
          verified: true,
          alreadyProcessed: false,
          reference: cleanRef,
          amount: verifiedNaira,
          amountInKobo: verifiedNaira * 100,
          currency: "NGN",
          paidAt: (/* @__PURE__ */ new Date()).toISOString(),
          customerEmail: userEmail,
          userId,
          gatewayResponse: "Approved"
        };
      }
    } catch (error) {
      return {
        success: false,
        verified: false,
        reference: cleanRef,
        error: error.message || "An unexpected error occurred while verifying payment with Paystack."
      };
    } finally {
      inFlightVerifications.delete(cleanRef);
    }
  })();
  inFlightVerifications.set(cleanRef, verificationPromise);
  return verificationPromise;
}
function verifyPaystackWebhookSignature(rawBody, signature) {
  if (!signature) return false;
  const secretKey = process.env.PAYSTACK_SECRET_KEY;
  if (!secretKey) return true;
  try {
    const hash = import_crypto2.default.createHmac("sha512", secretKey.trim()).update(rawBody).digest("hex");
    return hash === signature.trim();
  } catch {
    return false;
  }
}

// src/server/internationalNumbersService.ts
var import_fs = __toESM(require("fs"), 1);
var import_path = __toESM(require("path"), 1);
function getProviderBaseUrl() {
  let url = (process.env.INSTANTNUM_BASE_URL || process.env.INSTANTNUMS_BASE_URL || "https://instantnums.com/v1").trim();
  if (!url) return "https://instantnums.com/v1";
  url = url.replace(/^["']|["']$/g, "").trim();
  if (!/^https?:\/\//i.test(url)) {
    url = "https://" + url;
  }
  url = url.replace(/\/+$/, "");
  if (!/\/v1$/i.test(url)) {
    url += "/v1";
  }
  return url;
}
function getProviderApiKey() {
  const raw = (process.env.INSTANTNUM_API_KEY || process.env.INSTANTNUMS_API_KEY || "").trim();
  return raw.replace(/^["']|["']$/g, "").trim();
}
var pricingConfig = {
  usd_to_ngn_rate: Number(process.env.INSTANTNUMS_USD_TO_NGN_RATE || 1600),
  markup_below_1000_ngn: Number(process.env.INSTANTNUMS_MARKUP_BELOW_1000_NGN || 1e3),
  markup_1000_and_above_ngn: Number(process.env.INSTANTNUMS_MARKUP_1000_AND_ABOVE_NGN || 2e3)
};
function getPricingConfig() {
  return { ...pricingConfig };
}
function updatePricingConfig(newConfig) {
  if (typeof newConfig.usd_to_ngn_rate === "number" && newConfig.usd_to_ngn_rate > 0) {
    pricingConfig.usd_to_ngn_rate = newConfig.usd_to_ngn_rate;
  }
  if (typeof newConfig.markup_below_1000_ngn === "number" && newConfig.markup_below_1000_ngn >= 0) {
    pricingConfig.markup_below_1000_ngn = newConfig.markup_below_1000_ngn;
  }
  if (typeof newConfig.markup_1000_and_above_ngn === "number" && newConfig.markup_1000_and_above_ngn >= 0) {
    pricingConfig.markup_1000_and_above_ngn = newConfig.markup_1000_and_above_ngn;
  }
  return { ...pricingConfig };
}
function calculateRetailPrice(costUsd) {
  const rate = pricingConfig.usd_to_ngn_rate;
  const supplierCostNgn = Math.round(costUsd * rate * 100) / 100;
  const markupNgn = supplierCostNgn < 1e3 ? pricingConfig.markup_below_1000_ngn : pricingConfig.markup_1000_and_above_ngn;
  const customerPrice = Math.round((supplierCostNgn + markupNgn) * 100) / 100;
  return {
    costUsd,
    rate,
    supplierCostNgn,
    customerPrice,
    markupNgn
  };
}
function resolveCanonicalCountry(input) {
  const raw = String(input || "").trim();
  if (!raw) return "1";
  if (/^\d+$/.test(raw)) return raw;
  const withoutParens = raw.replace(/\(.*?\)/g, "").trim().toLowerCase();
  const insideParens = (raw.match(/\((.*?)\)/)?.[1] || "").trim().toLowerCase().replace(/^\+/, "");
  const str = withoutParens.replace(/['"]/g, "").replace(/\s+/g, " ").trim();
  if (["usa", "us", "united states", "united states of america", "america", "u.s.a.", "u.s.", "u.s", "1"].includes(str) || ["us", "usa", "1"].includes(insideParens)) {
    return "1";
  }
  if (["uk", "gb", "united kingdom", "great britain", "england", "britain", "44"].includes(str) || ["uk", "gb", "44"].includes(insideParens)) {
    return "2";
  }
  if (["netherlands", "holland", "nl", "31"].includes(str) || insideParens === "nl") return "3";
  if (["latvia", "lv"].includes(str)) return "5";
  if (["sweden", "se"].includes(str)) return "6";
  if (["russia", "ru", "kazakhstan", "kz"].includes(str)) return "7";
  if (["portugal", "pt"].includes(str)) return "8";
  if (["indonesia", "id"].includes(str)) return "9";
  if (["estonia", "ee"].includes(str)) return "10";
  if (["vietnam", "vn"].includes(str)) return "11";
  if (["philippines", "ph"].includes(str)) return "12";
  if (["romania", "ro"].includes(str)) return "13";
  if (["nigeria", "ng", "234"].includes(str) || insideParens === "ng") return "14";
  if (["india", "in", "91"].includes(str) || insideParens === "in") return "15";
  if (["kenya", "ke", "254"].includes(str) || insideParens === "ke") return "16";
  if (["denmark", "dk"].includes(str)) return "19";
  if (["malaysia", "my"].includes(str)) return "20";
  if (["poland", "pl"].includes(str)) return "21";
  if (["france", "fr", "33"].includes(str) || insideParens === "fr") return "23";
  if (["germany", "de", "49"].includes(str) || insideParens === "de") return "24";
  if (["ukraine", "ua"].includes(str)) return "25";
  if (["egypt", "eg", "20"].includes(str)) return "31";
  if (["ireland", "ie"].includes(str)) return "32";
  if (["canada", "ca"].includes(str) || insideParens === "ca") return "36";
  if (["ghana", "gh", "233"].includes(str) || insideParens === "gh") return "42";
  if (["argentina", "ar"].includes(str)) return "43";
  if (["cameroon", "cm"].includes(str)) return "45";
  if (["mexico", "mx"].includes(str)) return "53";
  if (["spain", "es"].includes(str)) return "55";
  if (["turkey", "tr"].includes(str)) return "60";
  if (["brazil", "br", "55"].includes(str) || insideParens === "br") return "68";
  if (["italy", "it"].includes(str)) return "79";
  if (["south africa", "za", "27"].includes(str) || insideParens === "za") return "153";
  if (["australia", "au", "61"].includes(str) || insideParens === "au") return "159";
  return raw;
}
function classifyProviderError(rawError) {
  if (!rawError) {
    return {
      code: "PROVIDER_UNAVAILABLE",
      customerMessage: "Number service is temporarily unavailable. Please try again shortly.",
      adminDetails: "Unknown provider error."
    };
  }
  const lower = rawError.toLowerCase();
  if (lower.includes("balance") || lower.includes("need $") || lower.includes("insufficient") || lower.includes("fund") || lower.includes("credit") || lower.includes("wallet") || lower.includes("usd") || lower.includes("account balance")) {
    return {
      code: "PROVIDER_INSUFFICIENT_BALANCE",
      customerMessage: "Number service is temporarily unavailable. Please try again shortly.",
      adminDetails: rawError
    };
  }
  if (lower.includes("out of stock") || lower.includes("no number") || lower.includes("no_numbers") || lower.includes("not enough numbers") || lower.includes("no available number")) {
    return {
      code: "OUT_OF_STOCK",
      customerMessage: "Numbers are temporarily out of stock for this selection. Please try another country or app.",
      adminDetails: rawError
    };
  }
  return {
    code: "PROVIDER_UNAVAILABLE",
    customerMessage: "Number service is temporarily unavailable. Please try again shortly.",
    adminDetails: rawError
  };
}
async function callUpstreamApi(endpoint, options = {}) {
  const apiKey = getProviderApiKey();
  if (!apiKey) {
    return {
      success: false,
      errorCode: "API_ERROR",
      error: "International numbers provider is not configured with an API key.",
      adminDetails: "Missing INSTANTNUM_API_KEY or INSTANTNUMS_API_KEY environment variable."
    };
  }
  const cleanEndpoint = "/" + endpoint.replace(/^\/+/, "");
  let url = `${getProviderBaseUrl()}${cleanEndpoint}`;
  if (options.params && Object.keys(options.params).length > 0) {
    const searchParams = new URLSearchParams(options.params);
    url += (url.includes("?") ? "&" : "?") + searchParams.toString();
  }
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 12e3);
  try {
    const fetchOptions = {
      method: options.method || "GET",
      headers: {
        "Authorization": `Bearer ${apiKey}`,
        "Accept": "application/json",
        "User-Agent": "SurestPlug-InternationalNumbers/2.0"
      },
      signal: controller.signal
    };
    if (options.body && options.method === "POST") {
      fetchOptions.headers = {
        ...fetchOptions.headers,
        "Content-Type": "application/json"
      };
      fetchOptions.body = JSON.stringify(options.body);
    }
    const response = await fetch(url, fetchOptions);
    clearTimeout(timeoutId);
    const text = await response.text();
    let data = null;
    try {
      data = JSON.parse(text);
    } catch {
      return {
        success: false,
        errorCode: "INVALID_RESPONSE",
        error: "Invalid response format received from international numbers provider.",
        adminDetails: text.slice(0, 200)
      };
    }
    if (response.ok) {
      if (data && typeof data.success !== "undefined" && (data.success === 0 || data.success === false)) {
        const rawErr2 = data?.message || data?.error || "Provider returned unsuccessful response";
        const classified2 = classifyProviderError(rawErr2);
        return {
          success: false,
          errorCode: classified2.code,
          error: classified2.customerMessage,
          adminDetails: classified2.adminDetails,
          data
        };
      }
      return { success: true, data };
    }
    const rawErr = data?.message || data?.error || `Provider error (${response.status})`;
    const classified = classifyProviderError(rawErr);
    return {
      success: false,
      errorCode: classified.code,
      error: classified.customerMessage,
      adminDetails: classified.adminDetails,
      data
    };
  } catch (err) {
    clearTimeout(timeoutId);
    const isTimeout = err?.name === "AbortError";
    return {
      success: false,
      errorCode: isTimeout ? "TIMEOUT" : "PROVIDER_UNAVAILABLE",
      error: isTimeout ? "Request to international numbers provider timed out." : "Network error connecting to international numbers provider.",
      adminDetails: err?.message || String(err)
    };
  }
}
var DEFAULT_COUNTRIES = [
  { id: "1", name: "USA", code: "us", flag: "\u{1F1FA}\u{1F1F8}", prefix: "+1" },
  { id: "2", name: "United Kingdom (UK)", code: "uk", flag: "\u{1F1EC}\u{1F1E7}", prefix: "+44" },
  { id: "3", name: "Netherlands", code: "nl", flag: "\u{1F1F3}\u{1F1F1}", prefix: "+31" },
  { id: "23", name: "France", code: "fr", flag: "\u{1F1EB}\u{1F1F7}", prefix: "+33" },
  { id: "24", name: "Germany", code: "de", flag: "\u{1F1E9}\u{1F1EA}", prefix: "+49" },
  { id: "68", name: "Brazil", code: "br", flag: "\u{1F1E7}\u{1F1F7}", prefix: "+55" },
  { id: "15", name: "India", code: "in", flag: "\u{1F1EE}\u{1F1F3}", prefix: "+91" },
  { id: "14", name: "Nigeria", code: "ng", flag: "\u{1F1F3}\u{1F1EC}", prefix: "+234" },
  { id: "42", name: "Ghana", code: "gh", flag: "\u{1F1EC}\u{1F1ED}", prefix: "+233" },
  { id: "16", name: "Kenya", code: "ke", flag: "\u{1F1F0}\u{1F1EA}", prefix: "+254" },
  { id: "70", name: "Uganda", code: "ug", flag: "\u{1F1FA}\u{1F1EC}", prefix: "+256" },
  { id: "71", name: "Angola", code: "ao", flag: "\u{1F1E6}\u{1F1F4}", prefix: "+244" },
  { id: "9", name: "Indonesia", code: "id", flag: "\u{1F1EE}\u{1F1E9}", prefix: "+62" },
  { id: "12", name: "Philippines", code: "ph", flag: "\u{1F1F5}\u{1F1ED}", prefix: "+63" },
  { id: "11", name: "Vietnam", code: "vn", flag: "\u{1F1FB}\u{1F1F3}", prefix: "+84" },
  { id: "20", name: "Malaysia", code: "my", flag: "\u{1F1F2}\u{1F1FE}", prefix: "+60" },
  { id: "52", name: "Thailand", code: "th", flag: "\u{1F1F9}\u{1F1ED}", prefix: "+66" },
  { id: "21", name: "Poland", code: "pl", flag: "\u{1F1F5}\u{1F1F1}", prefix: "+48" },
  { id: "25", name: "Ukraine", code: "ua", flag: "\u{1F1FA}\u{1F1E6}", prefix: "+380" },
  { id: "60", name: "Turkey", code: "tr", flag: "\u{1F1F9}\u{1F1F7}", prefix: "+90" },
  { id: "55", name: "Spain", code: "es", flag: "\u{1F1EA}\u{1F1F8}", prefix: "+34" },
  { id: "79", name: "Italy", code: "it", flag: "\u{1F1EE}\u{1F1F9}", prefix: "+39" },
  { id: "50", name: "Austria", code: "at", flag: "\u{1F1E6}\u{1F1F9}", prefix: "+43" },
  { id: "75", name: "Belgium", code: "be", flag: "\u{1F1E7}\u{1F1EA}", prefix: "+32" },
  { id: "53", name: "Mexico", code: "mx", flag: "\u{1F1F2}\u{1F1FD}", prefix: "+52" },
  { id: "39", name: "Colombia", code: "co", flag: "\u{1F1E8}\u{1F1F4}", prefix: "+57" },
  { id: "43", name: "Argentina", code: "ar", flag: "\u{1F1E6}\u{1F1F7}", prefix: "+54" },
  { id: "31", name: "Egypt", code: "eg", flag: "\u{1F1EA}\u{1F1EC}", prefix: "+20" },
  { id: "82", name: "Tunisia", code: "tn", flag: "\u{1F1F9}\u{1F1F3}", prefix: "+216" },
  { id: "41", name: "Morocco", code: "ma", flag: "\u{1F1F2}\u{1F1E6}", prefix: "+212" },
  { id: "88", name: "Kuwait", code: "kw", flag: "\u{1F1F0}\u{1F1FC}", prefix: "+965" },
  { id: "92", name: "Qatar", code: "qa", flag: "\u{1F1F6}\u{1F1E6}", prefix: "+974" },
  { id: "91", name: "Oman", code: "om", flag: "\u{1F1F4}\u{1F1F2}", prefix: "+968" },
  { id: "29", name: "Israel", code: "il", flag: "\u{1F1EE}\u{1F1F1}", prefix: "+972" }
];
var DEFAULT_SERVICES = [
  { id: "924", name: "TikTok/Douyin", category: "social", popular: true },
  { id: "900", name: "WhatsApp", category: "messaging", popular: true },
  { id: "901", name: "Telegram", category: "messaging", popular: true },
  { id: "902", name: "Google / Gmail / YouTube", category: "tech", popular: true },
  { id: "903", name: "Instagram", category: "social", popular: true },
  { id: "904", name: "Facebook", category: "social", popular: true },
  { id: "905", name: "X / Twitter", category: "social", popular: true },
  { id: "906", name: "OpenAI / ChatGPT", category: "ai", popular: true },
  { id: "907", name: "Netflix", category: "entertainment", popular: true },
  { id: "908", name: "Discord", category: "gaming", popular: true },
  { id: "909", name: "PayPal", category: "finance", popular: true },
  { id: "910", name: "Snapchat", category: "social", popular: true },
  { id: "911", name: "Amazon", category: "shopping", popular: true },
  { id: "912", name: "Apple", category: "tech", popular: true },
  { id: "913", name: "LinkedIn", category: "business", popular: true },
  { id: "914", name: "Tinder", category: "dating", popular: true },
  { id: "915", name: "Steam", category: "gaming", popular: true },
  { id: "916", name: "Uber / UberEats", category: "transport", popular: true },
  { id: "917", name: "Coinbase", category: "crypto", popular: true },
  { id: "918", name: "Binance", category: "crypto", popular: true },
  { id: "919", name: "WeChat", category: "messaging", popular: false },
  { id: "920", name: "Viber", category: "messaging", popular: false },
  { id: "921", name: "LINE", category: "messaging", popular: false },
  { id: "922", name: "Claude / Anthropic", category: "ai", popular: true },
  { id: "923", name: "Claude AI", category: "ai", popular: true },
  { id: "925", name: "Spotify", category: "music", popular: true }
];
async function getCountries() {
  const result = await callUpstreamApi("/countries");
  if (result.success && result.data) {
    const rawList = result.data.countries || (Array.isArray(result.data) ? result.data : []);
    if (Array.isArray(rawList) && rawList.length > 0) {
      const normalized = rawList.map((c) => {
        const id = String(c.ID ?? c.id ?? c.country_id ?? c.code ?? resolveCanonicalCountry(c.name || ""));
        const rawName = String(c.name || c.country_name || id);
        let displayName = rawName;
        if (id === "1" || rawName.toLowerCase().includes("united states") || rawName.toLowerCase() === "usa") {
          displayName = "USA";
        } else if (id === "2" || rawName.toLowerCase().includes("kingdom") || rawName.toLowerCase() === "uk") {
          displayName = "United Kingdom (UK)";
        }
        return {
          id: resolveCanonicalCountry(id || displayName),
          name: displayName,
          code: String(c.short_name || c.code || c.iso || id).toLowerCase(),
          flag: c.flag || "",
          prefix: c.cc ? `+${c.cc}` : c.prefix || ""
        };
      });
      return { success: true, countries: normalized };
    }
  }
  return { success: true, countries: DEFAULT_COUNTRIES };
}
async function getServices(country) {
  const params = {};
  if (country) {
    params.country = resolveCanonicalCountry(country);
  }
  const result = await callUpstreamApi("/services", { params });
  if (result.success && result.data) {
    const rawList = result.data.services || (Array.isArray(result.data) ? result.data : []);
    if (Array.isArray(rawList) && rawList.length > 0) {
      const normalized = rawList.map((s) => ({
        id: String(s.ID ?? s.id ?? s.service_id ?? s.code ?? ""),
        name: String(s.name || s.title || s.service_name || ""),
        category: s.category || "other",
        popular: !!(s.popular || s.is_popular || s.favourite)
      }));
      return { success: true, services: normalized };
    }
  }
  return { success: true, services: DEFAULT_SERVICES };
}
async function getStock(country, service) {
  const canonicalCountry = resolveCanonicalCountry(country);
  const result = await callUpstreamApi("/stock", {
    method: "GET",
    params: { service: String(service), country: canonicalCountry }
  });
  if (!result.success || !result.data) {
    const status = result.errorCode === "TIMEOUT" ? "TIMEOUT" : result.errorCode === "INVALID_RESPONSE" ? "INVALID_RESPONSE" : result.errorCode === "PROVIDER_INSUFFICIENT_BALANCE" ? "PROVIDER_INSUFFICIENT_BALANCE" : "PROVIDER_UNAVAILABLE";
    return {
      success: false,
      stock: null,
      // NEVER default to 0 on failure!
      status,
      error: result.error || "Failed to retrieve stock from provider."
    };
  }
  const raw = result.data;
  let detectedStock = null;
  const candidates = [
    raw.available,
    raw.stock,
    raw.count,
    raw.quantity,
    raw.data?.available,
    raw.data?.stock
  ];
  for (const c of candidates) {
    if (typeof c === "number" && !isNaN(c)) {
      detectedStock = c;
      break;
    } else if (typeof c === "string" && c.trim() !== "" && !isNaN(Number(c))) {
      detectedStock = Number(c);
      break;
    }
  }
  if (detectedStock === null) {
    return {
      success: false,
      stock: null,
      status: "INVALID_RESPONSE",
      error: "Provider response did not contain a valid numeric stock value."
    };
  }
  const stock = Math.max(0, detectedStock);
  return {
    success: true,
    stock,
    status: stock > 0 ? "AVAILABLE" : "OUT_OF_STOCK"
  };
}
async function getPrice(country, service) {
  const canonicalCountry = resolveCanonicalCountry(country);
  const result = await callUpstreamApi("/price", {
    method: "GET",
    params: { service: String(service), country: canonicalCountry }
  });
  if (!result.success || !result.data) {
    return {
      success: false,
      price: 1352,
      error: result.error || "Failed to check price from provider"
    };
  }
  const raw = result.data;
  let costUsd = null;
  const candidates = [raw.price_usd, raw.cost_usd, raw.price, raw.cost, raw.data?.price_usd, raw.data?.cost_usd];
  for (const c of candidates) {
    if (typeof c === "number" && !isNaN(c)) {
      costUsd = c;
      break;
    } else if (typeof c === "string" && c.trim() !== "" && !isNaN(Number(c))) {
      costUsd = Number(c);
      break;
    }
  }
  const finalCostUsd = costUsd !== null ? costUsd : 0.22;
  const pricing = calculateRetailPrice(finalCostUsd);
  return {
    success: true,
    price: pricing.customerPrice,
    costUsd: finalCostUsd
  };
}
async function getAvailability(country, service) {
  const canonicalCountry = resolveCanonicalCountry(country);
  const [stockRes, priceRes] = await Promise.all([
    getStock(canonicalCountry, service),
    getPrice(canonicalCountry, service)
  ]);
  const price = priceRes.success && typeof priceRes.price === "number" ? priceRes.price : 1352;
  if (!stockRes.success || stockRes.stock === null || typeof stockRes.stock !== "number") {
    return {
      success: false,
      available: false,
      stock: null,
      price,
      status: stockRes.status || "PROVIDER_UNAVAILABLE",
      error: stockRes.error || "Unable to verify live stock with provider."
    };
  }
  const verifiedStock = stockRes.stock;
  if (verifiedStock > 0) {
    return {
      success: true,
      available: true,
      stock: verifiedStock,
      price,
      status: "AVAILABLE"
    };
  } else {
    return {
      success: true,
      available: false,
      stock: 0,
      price,
      status: "OUT_OF_STOCK",
      error: "Numbers are temporarily out of stock for this selection."
    };
  }
}
function sanitizeOtpCode(val) {
  if (val === null || val === void 0) return null;
  const str = String(val).trim();
  if (!str) return null;
  const forbidden = [
    "none",
    "null",
    "undefined",
    "n/a",
    "na",
    "false",
    "true",
    "waiting",
    "pending",
    "0",
    "---",
    "no code",
    "none received",
    "awaiting"
  ];
  if (forbidden.includes(str.toLowerCase())) {
    return null;
  }
  if (str.length > 25 && str.includes(" ")) {
    const match = str.match(/\b\d{4,8}\b/);
    return match ? match[0] : null;
  }
  return str;
}
function sanitizeSmsText(val) {
  if (val === null || val === void 0) return null;
  const str = String(val).trim();
  if (!str) return null;
  const forbidden = ["none", "null", "undefined", "n/a", "na", "false"];
  if (forbidden.includes(str.toLowerCase())) return null;
  return str.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#039;");
}
var ORDERS_FILE = import_path.default.resolve(process.cwd(), "intl_orders_store.json");
function loadOrdersFromDisk() {
  try {
    if (import_fs.default.existsSync(ORDERS_FILE)) {
      const content = import_fs.default.readFileSync(ORDERS_FILE, "utf-8");
      return JSON.parse(content) || [];
    }
  } catch (e) {
    console.warn("[Server Orders] Failed to read intl_orders_store.json:", e);
  }
  return [];
}
var serverOrdersCache = loadOrdersFromDisk();
function persistOrdersToDisk() {
  try {
    import_fs.default.writeFileSync(ORDERS_FILE, JSON.stringify(serverOrdersCache.slice(-500), null, 2), "utf-8");
  } catch (e) {
    console.warn("[Server Orders] Failed to write intl_orders_store.json:", e);
  }
}
function recordServerOrder(order) {
  const existingIdx = serverOrdersCache.findIndex((o) => o.orderId === order.orderId);
  const nowIso = (/* @__PURE__ */ new Date()).toISOString();
  const purchasedAt = order.purchasedAt || (existingIdx !== -1 ? serverOrdersCache[existingIdx].purchasedAt : null) || order.createdAt || nowIso;
  const expiryDurationMinutes = Number(process.env.INTL_ORDER_EXPIRY_MINUTES) || 20;
  const defaultExpiresAt = new Date(new Date(purchasedAt).getTime() + expiryDurationMinutes * 60 * 1e3).toISOString();
  const expiresAt = order.expiresAt || (existingIdx !== -1 ? serverOrdersCache[existingIdx].expiresAt : null) || defaultExpiresAt;
  const record = {
    id: String(order.orderId || order.id || Date.now()),
    orderId: String(order.orderId || order.id || ""),
    userId: order.userId || (existingIdx !== -1 ? serverOrdersCache[existingIdx].userId : void 0),
    userEmail: order.userEmail || (existingIdx !== -1 ? serverOrdersCache[existingIdx].userEmail : void 0),
    orderReference: order.orderReference || (existingIdx !== -1 ? serverOrdersCache[existingIdx].orderReference : void 0),
    countryId: String(order.countryId || (existingIdx !== -1 ? serverOrdersCache[existingIdx].countryId : "1")),
    countryName: order.countryName || (existingIdx !== -1 ? serverOrdersCache[existingIdx].countryName : "USA"),
    serviceId: String(order.serviceId || (existingIdx !== -1 ? serverOrdersCache[existingIdx].serviceId : "")),
    serviceName: order.serviceName || (existingIdx !== -1 ? serverOrdersCache[existingIdx].serviceName : "App"),
    phoneNumber: order.phoneNumber || (existingIdx !== -1 ? serverOrdersCache[existingIdx].phoneNumber : ""),
    customerPrice: Number(order.customerPrice || (existingIdx !== -1 ? serverOrdersCache[existingIdx].customerPrice : 0)),
    costUsd: Number(order.costUsd || (existingIdx !== -1 ? serverOrdersCache[existingIdx].costUsd : 0)),
    providerStatus: order.providerStatus || (existingIdx !== -1 ? serverOrdersCache[existingIdx].providerStatus : "waiting"),
    normalizedStatus: order.normalizedStatus || (existingIdx !== -1 ? serverOrdersCache[existingIdx].normalizedStatus : "waiting"),
    statusLabel: order.statusLabel || (existingIdx !== -1 ? serverOrdersCache[existingIdx].statusLabel : "Waiting for SMS code..."),
    sms: sanitizeOtpCode(order.sms ?? (existingIdx !== -1 ? serverOrdersCache[existingIdx].sms : null)),
    fullSms: sanitizeSmsText(order.fullSms ?? (existingIdx !== -1 ? serverOrdersCache[existingIdx].fullSms : null)),
    purchasedAt,
    expiresAt,
    receivedAt: order.receivedAt || (existingIdx !== -1 ? serverOrdersCache[existingIdx].receivedAt : null),
    createdAt: order.createdAt || (existingIdx !== -1 ? serverOrdersCache[existingIdx].createdAt : purchasedAt),
    updatedAt: nowIso,
    refunded: order.refunded !== void 0 ? Boolean(order.refunded) : existingIdx !== -1 ? Boolean(serverOrdersCache[existingIdx].refunded) : false,
    cancelledAt: order.cancelledAt || (existingIdx !== -1 ? serverOrdersCache[existingIdx].cancelledAt : null),
    providerCancelled: order.providerCancelled !== void 0 ? Boolean(order.providerCancelled) : existingIdx !== -1 ? Boolean(serverOrdersCache[existingIdx].providerCancelled) : false,
    cancellationPending: order.cancellationPending !== void 0 ? Boolean(order.cancellationPending) : existingIdx !== -1 ? Boolean(serverOrdersCache[existingIdx].cancellationPending) : false,
    cancellationAttempts: order.cancellationAttempts ?? (existingIdx !== -1 ? serverOrdersCache[existingIdx].cancellationAttempts : 0),
    cancellationError: order.cancellationError ?? (existingIdx !== -1 ? serverOrdersCache[existingIdx].cancellationError : null)
  };
  if (existingIdx !== -1) {
    serverOrdersCache[existingIdx] = { ...serverOrdersCache[existingIdx], ...record, updatedAt: nowIso };
  } else {
    serverOrdersCache.unshift(record);
  }
  persistOrdersToDisk();
  return record;
}
function getServerOrder(orderId) {
  return serverOrdersCache.find((o) => o.orderId === orderId || o.id === orderId) || null;
}
function getServerOrders(userId, userEmail) {
  let list = [...serverOrdersCache];
  if (userId) {
    list = list.filter((o) => !o.userId || o.userId === userId);
  }
  if (userEmail) {
    list = list.filter((o) => !o.userEmail || o.userEmail.toLowerCase() === userEmail.toLowerCase());
  }
  return list;
}
function updateServerOrderStatus(orderId, updates) {
  const idx = serverOrdersCache.findIndex((o) => o.orderId === orderId || o.id === orderId);
  if (idx === -1) return null;
  serverOrdersCache[idx] = {
    ...serverOrdersCache[idx],
    ...updates,
    updatedAt: (/* @__PURE__ */ new Date()).toISOString()
  };
  persistOrdersToDisk();
  return serverOrdersCache[idx];
}
async function purchaseNumber(country, service, meta) {
  const canonicalCountry = resolveCanonicalCountry(country);
  const result = await callUpstreamApi("/sms/purchase", {
    method: "POST",
    body: { service: String(service), country: canonicalCountry }
  });
  if (!result.success || !result.data) {
    return {
      success: false,
      errorCode: result.errorCode || "API_ERROR",
      error: result.error || "Number service is temporarily unavailable. Please try again shortly."
    };
  }
  const costUsd = Number(result.data.cost_usd || 0);
  const pricing = calculateRetailPrice(costUsd);
  const orderId = String(result.data.order_id || result.data.id || "");
  const phoneNumber = String(result.data.phone_number || result.data.number || "");
  const orderStatus = String(result.data.status || "waiting").toLowerCase();
  const nowMs = Date.now();
  const purchasedAt = new Date(nowMs).toISOString();
  const expiryMinutes = Number(process.env.INTL_ORDER_EXPIRY_MINUTES) || 20;
  const expiresAt = new Date(nowMs + expiryMinutes * 60 * 1e3).toISOString();
  const orderPayload = {
    order_id: orderId,
    phone_number: phoneNumber,
    customer_price: pricing.customerPrice,
    price: pricing.customerPrice,
    cost_usd: costUsd,
    purchased_at: purchasedAt,
    expires_at: expiresAt,
    status: orderStatus
  };
  recordServerOrder({
    orderId,
    phoneNumber,
    customerPrice: pricing.customerPrice,
    costUsd,
    countryId: canonicalCountry,
    serviceId: String(service),
    userId: meta?.userId,
    userEmail: meta?.userEmail,
    orderReference: meta?.orderReference,
    providerStatus: orderStatus,
    normalizedStatus: "waiting",
    statusLabel: "Waiting for SMS code...",
    sms: null,
    fullSms: null,
    purchasedAt,
    expiresAt
  });
  return {
    success: true,
    orderId,
    phoneNumber,
    price: pricing.customerPrice,
    customer_price: pricing.customerPrice,
    costUsd,
    purchasedAt,
    expiresAt,
    status: orderStatus,
    data: orderPayload
  };
}
async function getOrderStatus(orderId) {
  const cleanOrderId = encodeURIComponent(orderId);
  const existing = getServerOrder(orderId);
  const result = await callUpstreamApi(`/sms/${cleanOrderId}`, { method: "GET" });
  if (!result.success || !result.data) {
    return {
      success: false,
      orderId,
      providerStatus: existing?.providerStatus || "error",
      normalizedStatus: "error",
      status: existing?.normalizedStatus || "waiting",
      statusLabel: "Temporary connection check issue with provider",
      isTerminal: false,
      sms: existing?.sms || null,
      fullSms: existing?.fullSms || null,
      error: result.error || "Failed to check order status with provider"
    };
  }
  const rawData = result.data;
  const rawStatus = String(rawData.status || "waiting").toLowerCase().trim();
  const rawSms = rawData.sms;
  const rawFullSms = rawData.full_sms;
  let validSms = sanitizeOtpCode(rawSms);
  const cleanFullSms = sanitizeSmsText(rawFullSms || rawSms);
  if (!validSms && rawFullSms) {
    const match = String(rawFullSms).match(/\b\d{4,8}\b/);
    if (match) {
      validSms = match[0];
    }
  }
  let normalizedStatus = "waiting";
  let statusLabel = "Waiting for SMS code...";
  if (rawStatus === "cancelled" || rawStatus === "canceled") {
    normalizedStatus = "cancelled";
    statusLabel = "Cancelled";
  } else if (rawStatus === "refunded") {
    normalizedStatus = "refunded";
    statusLabel = "Refunded to Wallet";
  } else if (rawStatus === "expired" || rawStatus === "timeout") {
    normalizedStatus = "expired";
    statusLabel = "Expired (Refunded)";
  } else if (validSms !== null || rawStatus === "received" || rawStatus === "code_received" || rawStatus === "sms_received") {
    normalizedStatus = "received";
    statusLabel = "SMS Received";
  } else if (rawStatus === "finished" || rawStatus === "completed") {
    if (validSms !== null || existing?.sms) {
      normalizedStatus = "completed";
      statusLabel = "Completed";
    } else {
      normalizedStatus = "expired";
      statusLabel = "Expired (No Code Received)";
    }
  } else {
    normalizedStatus = "waiting";
    statusLabel = "Waiting for SMS code...";
  }
  const isTerminal = ["completed", "cancelled", "refunded", "expired"].includes(normalizedStatus) || normalizedStatus === "received";
  updateServerOrderStatus(orderId, {
    providerStatus: rawStatus,
    normalizedStatus,
    statusLabel,
    sms: validSms || existing?.sms || null,
    fullSms: cleanFullSms || existing?.fullSms || null,
    receivedAt: validSms ? existing?.receivedAt || (/* @__PURE__ */ new Date()).toISOString() : null,
    expiresAt: rawData.expires_at || existing?.expiresAt || null
  });
  return {
    success: true,
    orderId: String(rawData.order_id || orderId),
    providerStatus: rawStatus,
    normalizedStatus,
    status: normalizedStatus,
    statusLabel,
    isTerminal,
    sms: validSms,
    fullSms: cleanFullSms,
    expiresAt: rawData.expires_at || existing?.expiresAt || null,
    receivedAt: validSms ? existing?.receivedAt || (/* @__PURE__ */ new Date()).toISOString() : null
  };
}
async function cancelOrder(orderId) {
  const cleanOrderId = encodeURIComponent(orderId);
  const existing = getServerOrder(orderId);
  if (existing && (existing.normalizedStatus === "cancelled" || existing.normalizedStatus === "refunded" || existing.normalizedStatus === "expired" || existing.refunded)) {
    return {
      success: true,
      orderId,
      providerStatus: existing.providerStatus || "cancelled",
      normalizedStatus: existing.normalizedStatus,
      status: existing.normalizedStatus,
      refunded: true
    };
  }
  if (existing && (existing.sms || existing.normalizedStatus === "received" || existing.normalizedStatus === "completed")) {
    return {
      success: false,
      orderId,
      providerStatus: existing.providerStatus || "completed",
      normalizedStatus: existing.normalizedStatus,
      status: existing.normalizedStatus,
      refunded: false,
      error: "Cannot cancel an order that has already received an SMS verification code."
    };
  }
  const result = await callUpstreamApi(`/sms/${cleanOrderId}/cancel`, {
    method: "POST",
    body: {}
  });
  if (!result.success || !result.data) {
    const errText = String(result.error || "").toLowerCase();
    if (errText.includes("already cancelled") || errText.includes("already canceled") || errText.includes("already refunded") || errText.includes("expired") || errText.includes("not active")) {
      updateServerOrderStatus(orderId, {
        providerStatus: "cancelled",
        normalizedStatus: "cancelled",
        statusLabel: "Cancelled (Refunded)",
        refunded: true,
        cancelledAt: existing?.cancelledAt || (/* @__PURE__ */ new Date()).toISOString(),
        providerCancelled: true,
        cancellationPending: false
      });
      return {
        success: true,
        orderId,
        providerStatus: "cancelled",
        normalizedStatus: "cancelled",
        status: "cancelled",
        refunded: true
      };
    }
    return {
      success: false,
      orderId,
      providerStatus: "error",
      normalizedStatus: "error",
      status: "error",
      refunded: false,
      error: result.error || "Failed to cancel order with provider"
    };
  }
  const rawStatus = String(result.data.status || "cancelled").toLowerCase().trim();
  updateServerOrderStatus(orderId, {
    providerStatus: rawStatus,
    normalizedStatus: "cancelled",
    statusLabel: "Cancelled (Refunded)",
    refunded: true,
    cancelledAt: (/* @__PURE__ */ new Date()).toISOString(),
    providerCancelled: true,
    cancellationPending: false,
    cancellationError: null
  });
  return {
    success: true,
    orderId: String(result.data.order_id || orderId),
    providerStatus: rawStatus,
    normalizedStatus: "cancelled",
    status: "cancelled",
    refunded: true
  };
}
var isExpiryProcessing = false;
var expiryIntervalTimer = null;
async function processExpiredOrders() {
  if (isExpiryProcessing) {
    return { processed: 0, cancelled: 0, failed: 0 };
  }
  isExpiryProcessing = true;
  let processed = 0;
  let cancelled = 0;
  let failed = 0;
  try {
    const nowMs = Date.now();
    const candidates = serverOrdersCache.filter((o) => {
      if (o.normalizedStatus === "cancelled" || o.normalizedStatus === "refunded" || o.normalizedStatus === "expired" || o.refunded === true) {
        return false;
      }
      if (o.sms || o.normalizedStatus === "received" || o.normalizedStatus === "completed") {
        return false;
      }
      if (o.cancellationPending) {
        return true;
      }
      if (o.expiresAt) {
        const expMs = new Date(o.expiresAt).getTime();
        if (!isNaN(expMs) && expMs <= nowMs) {
          return true;
        }
      }
      return false;
    });
    for (const order of candidates) {
      processed++;
      try {
        const checkRes = await callUpstreamApi(`/sms/${encodeURIComponent(order.orderId)}`, { method: "GET" });
        if (checkRes.success && checkRes.data) {
          const rawSms = sanitizeOtpCode(checkRes.data.sms);
          const rawFullSms = sanitizeSmsText(checkRes.data.full_sms || checkRes.data.sms);
          let extractedOtp = rawSms;
          if (!extractedOtp && rawFullSms) {
            const match = String(rawFullSms).match(/\b\d{4,8}\b/);
            if (match) extractedOtp = match[0];
          }
          if (extractedOtp) {
            console.log(`[Expiry Worker] Order ${order.orderId} received SMS ${extractedOtp}. Preserving order.`);
            updateServerOrderStatus(order.orderId, {
              sms: extractedOtp,
              fullSms: rawFullSms,
              normalizedStatus: "received",
              statusLabel: "SMS Received",
              cancellationPending: false,
              receivedAt: (/* @__PURE__ */ new Date()).toISOString()
            });
            continue;
          }
          const rawStatus = String(checkRes.data.status || "").toLowerCase();
          if (rawStatus === "cancelled" || rawStatus === "canceled" || rawStatus === "expired" || rawStatus === "refunded") {
            console.log(`[Expiry Worker] Order ${order.orderId} already terminal on provider (${rawStatus}).`);
            updateServerOrderStatus(order.orderId, {
              normalizedStatus: "expired",
              providerStatus: rawStatus,
              statusLabel: "Expired / Cancelled",
              cancellationPending: false,
              providerCancelled: true,
              cancelledAt: order.cancelledAt || (/* @__PURE__ */ new Date()).toISOString(),
              refunded: true
            });
            cancelled++;
            continue;
          }
        }
      } catch {
      }
      updateServerOrderStatus(order.orderId, {
        cancellationPending: true,
        statusLabel: "Expired \u2014 Cancelling..."
      });
      console.log(`[Expiry Worker] Auto-cancelling expired order ${order.orderId} (expired at ${order.expiresAt})...`);
      const cancelRes = await cancelOrder(order.orderId);
      if (cancelRes.success) {
        console.log(`[Expiry Worker] Successfully cancelled expired order ${order.orderId}.`);
        updateServerOrderStatus(order.orderId, {
          normalizedStatus: "expired",
          providerStatus: cancelRes.providerStatus || "cancelled",
          statusLabel: "Expired / Cancelled",
          cancellationPending: false,
          providerCancelled: true,
          cancelledAt: (/* @__PURE__ */ new Date()).toISOString(),
          refunded: true,
          cancellationError: null
        });
        cancelled++;
      } else {
        console.warn(`[Expiry Worker] Cancellation failed for order ${order.orderId}: ${cancelRes.error}. Will retry on next tick.`);
        updateServerOrderStatus(order.orderId, {
          cancellationPending: true,
          cancellationAttempts: (order.cancellationAttempts || 0) + 1,
          cancellationError: cancelRes.error || "Provider cancellation failed",
          statusLabel: "Cancellation Pending (Retrying...)"
        });
        failed++;
      }
    }
  } catch (err) {
    console.error("[Expiry Worker] Error processing expired orders:", err?.message || err);
  } finally {
    isExpiryProcessing = false;
  }
  return { processed, cancelled, failed };
}
function startIntlExpiryWorker(intervalMs = 5e3) {
  if (expiryIntervalTimer) {
    clearInterval(expiryIntervalTimer);
  }
  processExpiredOrders().catch((e) => console.warn("[Expiry Worker Boot] Error:", e));
  expiryIntervalTimer = setInterval(() => {
    processExpiredOrders().catch((e) => console.warn("[Expiry Worker Loop] Error:", e));
  }, intervalMs);
  console.log(`[Expiry Worker] International numbers expiry worker started (interval: ${intervalMs}ms).`);
}
async function getBalance() {
  const rate = pricingConfig.usd_to_ngn_rate > 0 ? pricingConfig.usd_to_ngn_rate : 1600;
  const result = await callUpstreamApi("/balance", { method: "GET" });
  if (!result.success || !result.data) {
    console.warn("[InstantNums Balance] Query failed:", result.error);
    return {
      success: false,
      balance_usd: 0,
      balance_ngn: 0,
      balanceUsd: 0,
      balanceNgn: 0,
      exchangeRate: rate,
      rate,
      currency: "USD",
      error: result.error || "Failed to fetch provider balance"
    };
  }
  const raw = result.data;
  console.log("[InstantNums Balance] Upstream returned:", {
    success: raw.success,
    balance_usd: raw.balance_usd,
    balance_ngn: raw.balance_ngn,
    currency: raw.currency
  });
  const rawUsd = typeof raw.balance_usd === "number" ? raw.balance_usd : parseFloat(raw.balance_usd) || 0;
  const rawNgn = typeof raw.balance_ngn === "number" ? raw.balance_ngn : parseFloat(raw.balance_ngn) || 0;
  const ngnInUsd = rawNgn > 0 ? rawNgn / rate : 0;
  const totalUsd = Math.round((rawUsd + ngnInUsd) * 100) / 100;
  const totalNgn = Math.round(totalUsd * rate * 100) / 100;
  return {
    success: true,
    balance_usd: totalUsd,
    balance_ngn: totalNgn,
    balanceUsd: totalUsd,
    balanceNgn: totalNgn,
    exchangeRate: rate,
    rate,
    currency: raw.currency || "USD",
    wallets: {
      usd: rawUsd,
      ngn: rawNgn
    },
    lastUpdated: (/* @__PURE__ */ new Date()).toISOString()
  };
}

// src/server/resellerService.ts
var import_fs2 = __toESM(require("fs"), 1);
var import_path2 = __toESM(require("path"), 1);
var import_crypto3 = __toESM(require("crypto"), 1);
var DATA_DIR = import_path2.default.resolve(process.cwd(), "data");
var RESELLERS_FILE = import_path2.default.join(DATA_DIR, "resellers.json");
var RESELLER_ORDERS_FILE = import_path2.default.join(DATA_DIR, "reseller_orders.json");
var RESELLER_LOGS_FILE = import_path2.default.join(DATA_DIR, "reseller_logs.json");
var RESELLER_CONFIG_FILE = import_path2.default.join(DATA_DIR, "reseller_config.json");
try {
  if (!import_fs2.default.existsSync(DATA_DIR)) {
    import_fs2.default.mkdirSync(DATA_DIR, { recursive: true });
  }
} catch (e) {
  console.warn("[ResellerService] Data directory check warning:", e);
}
var DEFAULT_CONFIG = {
  smm_discount_percent: 5,
  accounts_discount_percent: 5,
  numbers_discount_percent: 5,
  marketplace_discount_percent: 5,
  min_balance_threshold: 5e3,
  // ₦5,000 strict minimum requirement
  enabled_categories: {
    smm: true,
    accounts: true,
    numbers: true,
    marketplace: true
  },
  disabled_product_ids: []
};
var resellersCache = /* @__PURE__ */ new Map();
var ordersCache = [];
var logsCache = [];
var pricingConfig2 = { ...DEFAULT_CONFIG };
function loadPersistence() {
  try {
    if (import_fs2.default.existsSync(RESELLERS_FILE)) {
      const data = JSON.parse(import_fs2.default.readFileSync(RESELLERS_FILE, "utf-8"));
      resellersCache = new Map(Object.entries(data));
    }
  } catch (e) {
    console.warn("[ResellerService] Failed to load resellers file:", e);
  }
  try {
    if (import_fs2.default.existsSync(RESELLER_ORDERS_FILE)) {
      ordersCache = JSON.parse(import_fs2.default.readFileSync(RESELLER_ORDERS_FILE, "utf-8"));
    }
  } catch (e) {
    console.warn("[ResellerService] Failed to load orders file:", e);
  }
  try {
    if (import_fs2.default.existsSync(RESELLER_LOGS_FILE)) {
      logsCache = JSON.parse(import_fs2.default.readFileSync(RESELLER_LOGS_FILE, "utf-8"));
    }
  } catch (e) {
    console.warn("[ResellerService] Failed to load logs file:", e);
  }
  try {
    if (import_fs2.default.existsSync(RESELLER_CONFIG_FILE)) {
      pricingConfig2 = { ...DEFAULT_CONFIG, ...JSON.parse(import_fs2.default.readFileSync(RESELLER_CONFIG_FILE, "utf-8")) };
    }
  } catch (e) {
    console.warn("[ResellerService] Failed to load config file:", e);
  }
}
loadPersistence();
function saveResellers() {
  try {
    const obj = {};
    resellersCache.forEach((val, key) => {
      obj[key] = val;
    });
    import_fs2.default.writeFileSync(RESELLERS_FILE, JSON.stringify(obj, null, 2), "utf-8");
  } catch (e) {
    console.error("[ResellerService] Error saving resellers:", e);
  }
}
function saveOrders() {
  try {
    import_fs2.default.writeFileSync(RESELLER_ORDERS_FILE, JSON.stringify(ordersCache.slice(-2e3), null, 2), "utf-8");
  } catch (e) {
    console.error("[ResellerService] Error saving orders:", e);
  }
}
function saveLogs() {
  try {
    import_fs2.default.writeFileSync(RESELLER_LOGS_FILE, JSON.stringify(logsCache.slice(-2e3), null, 2), "utf-8");
  } catch (e) {
    console.error("[ResellerService] Error saving logs:", e);
  }
}
function saveConfig() {
  try {
    import_fs2.default.writeFileSync(RESELLER_CONFIG_FILE, JSON.stringify(pricingConfig2, null, 2), "utf-8");
  } catch (e) {
    console.error("[ResellerService] Error saving config:", e);
  }
}
function hashApiKey(rawKey) {
  return import_crypto3.default.createHash("sha256").update(rawKey.trim()).digest("hex");
}
function generateApiKeyString() {
  const randomHex = import_crypto3.default.randomBytes(24).toString("hex");
  return `sp_live_${randomHex}`;
}
function generateWebhookSecret() {
  const randomHex = import_crypto3.default.randomBytes(16).toString("hex");
  return `sp_whsec_${randomHex}`;
}
function maskApiKey(apiKey) {
  if (!apiKey || apiKey.length < 16) return "sp_live_\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022";
  const prefix = apiKey.substring(0, 12);
  const suffix = apiKey.substring(apiKey.length - 4);
  return `${prefix}...${suffix}`;
}
function getOrCreateResellerProfile(userId, email, fullName, currentBalance) {
  const key = String(userId);
  let profile = resellersCache.get(key);
  const isEligible = currentBalance >= pricingConfig2.min_balance_threshold;
  if (!profile) {
    profile = {
      user_id: userId,
      full_name: fullName || "Surest Plug Reseller",
      email: email.toLowerCase().trim(),
      status: "active",
      balance: currentBalance,
      currency: "NGN",
      min_balance_threshold: pricingConfig2.min_balance_threshold,
      is_eligible: isEligible,
      has_api_key: false,
      total_orders: 0,
      total_spent: 0,
      created_at: (/* @__PURE__ */ new Date()).toISOString(),
      updated_at: (/* @__PURE__ */ new Date()).toISOString()
    };
    resellersCache.set(key, profile);
    saveResellers();
  } else {
    profile.balance = currentBalance;
    profile.is_eligible = isEligible;
    if (fullName && fullName !== profile.full_name) profile.full_name = fullName;
    if (email && email !== profile.email) profile.email = email.toLowerCase().trim();
  }
  return sanitizeResellerProfile(profile);
}
function sanitizeResellerProfile(profile) {
  const { apiKeyHash, ...safe } = profile;
  return {
    ...safe,
    currency: "NGN",
    min_balance_threshold: pricingConfig2.min_balance_threshold,
    is_eligible: (safe.balance ?? 0) >= pricingConfig2.min_balance_threshold
  };
}
function generateResellerKey(userId, email, fullName, currentBalance) {
  const minRequired = pricingConfig2.min_balance_threshold;
  if (currentBalance < minRequired) {
    return {
      success: false,
      error: `Reseller API access requires a minimum wallet balance of \u20A6${minRequired.toLocaleString()}. Your current balance is \u20A6${currentBalance.toLocaleString()}. Please top up your wallet first.`
    };
  }
  const rawKey = generateApiKeyString();
  const keyHash = hashApiKey(rawKey);
  const masked = maskApiKey(rawKey);
  const prefix = rawKey.substring(0, 12);
  const now = (/* @__PURE__ */ new Date()).toISOString();
  const key = String(userId);
  let profile = resellersCache.get(key);
  if (!profile) {
    profile = {
      user_id: userId,
      full_name: fullName,
      email: email.toLowerCase().trim(),
      status: "active",
      balance: currentBalance,
      currency: "NGN",
      min_balance_threshold: minRequired,
      is_eligible: true,
      has_api_key: true,
      api_key_prefix: prefix,
      api_key_masked: masked,
      api_key_created_at: now,
      api_key_last_used_at: null,
      total_orders: 0,
      total_spent: 0,
      created_at: now,
      updated_at: now
    };
  } else {
    profile.status = "active";
    profile.balance = currentBalance;
    profile.is_eligible = true;
    profile.has_api_key = true;
    profile.api_key_prefix = prefix;
    profile.api_key_masked = masked;
    profile.api_key_created_at = now;
    profile.updated_at = now;
  }
  profile.apiKeyHash = keyHash;
  resellersCache.set(key, profile);
  saveResellers();
  return {
    success: true,
    apiKey: rawKey,
    maskedKey: masked,
    prefix
  };
}
function revokeResellerKey(userId) {
  const key = String(userId);
  const profile = resellersCache.get(key);
  if (!profile) {
    return { success: false, message: "Reseller account not found." };
  }
  profile.has_api_key = false;
  profile.api_key_prefix = void 0;
  profile.api_key_masked = void 0;
  profile.api_key_created_at = void 0;
  profile.apiKeyHash = void 0;
  profile.updated_at = (/* @__PURE__ */ new Date()).toISOString();
  resellersCache.set(key, profile);
  saveResellers();
  return { success: true, message: "API Key has been successfully revoked." };
}
function syncResellerWalletBalance(userId, newBalance) {
  const key = String(userId);
  const profile = resellersCache.get(key);
  if (!profile) {
    return { success: false, error: "Reseller account not found." };
  }
  const minRequired = pricingConfig2.min_balance_threshold;
  const validBalance = Math.max(0, Number(newBalance.toFixed(2)));
  profile.balance = validBalance;
  profile.min_balance_threshold = minRequired;
  profile.is_eligible = validBalance >= minRequired;
  profile.updated_at = (/* @__PURE__ */ new Date()).toISOString();
  resellersCache.set(key, profile);
  saveResellers();
  return {
    success: true,
    profile: sanitizeResellerProfile(profile)
  };
}
function updateResellerWebhookConfig(userId, webhookUrl) {
  const key = String(userId);
  const profile = resellersCache.get(key);
  if (!profile) {
    return { success: false, error: "Reseller account not found." };
  }
  if (webhookUrl && webhookUrl.trim()) {
    const cleanUrl = webhookUrl.trim();
    if (!cleanUrl.startsWith("http://") && !cleanUrl.startsWith("https://")) {
      return { success: false, error: "Webhook URL must start with http:// or https://" };
    }
    profile.webhook_url = cleanUrl;
    profile.webhook_enabled = true;
    if (!profile.webhook_secret) {
      profile.webhook_secret = generateWebhookSecret();
    }
  } else {
    profile.webhook_url = null;
    profile.webhook_enabled = false;
  }
  profile.updated_at = (/* @__PURE__ */ new Date()).toISOString();
  resellersCache.set(key, profile);
  saveResellers();
  return {
    success: true,
    webhookSecret: profile.webhook_secret || void 0
  };
}
function authenticateResellerToken(rawAuthHeader, options) {
  if (!rawAuthHeader || !rawAuthHeader.trim()) {
    return {
      authenticated: false,
      statusCode: 401,
      code: "UNAUTHORIZED",
      error: "Missing Authorization header. Expected format: Authorization: Bearer sp_live_..."
    };
  }
  let token = rawAuthHeader.trim();
  if (token.toLowerCase().startsWith("bearer ")) {
    token = token.slice(7).trim();
  }
  if (!token) {
    return {
      authenticated: false,
      statusCode: 401,
      code: "INVALID_TOKEN",
      error: "Empty API key provided."
    };
  }
  const keyHash = hashApiKey(token);
  let matchedProfile = null;
  for (const p of resellersCache.values()) {
    if (p.apiKeyHash && p.apiKeyHash === keyHash) {
      matchedProfile = p;
      break;
    }
  }
  if (!matchedProfile) {
    return {
      authenticated: false,
      statusCode: 401,
      code: "INVALID_API_KEY",
      error: "Invalid or revoked API key. Please check your credentials."
    };
  }
  if (matchedProfile.status === "suspended") {
    return {
      authenticated: false,
      statusCode: 403,
      code: "ACCOUNT_SUSPENDED",
      error: "Your Reseller API account has been suspended by administration. Please contact support."
    };
  }
  const minRequired = pricingConfig2.min_balance_threshold;
  const isBelowThreshold = (matchedProfile.balance ?? 0) < minRequired;
  if (isBelowThreshold && !options?.allowBelowThreshold) {
    return {
      authenticated: false,
      statusCode: 403,
      code: "INSUFFICIENT_RESELLER_BALANCE",
      error: `Reseller API requires a minimum wallet balance of \u20A6${minRequired.toLocaleString()}. Current balance: \u20A6${(matchedProfile.balance ?? 0).toLocaleString()}. Please top up your wallet to continue using the API.`
    };
  }
  matchedProfile.api_key_last_used_at = (/* @__PURE__ */ new Date()).toISOString();
  saveResellers();
  return {
    authenticated: true,
    reseller: sanitizeResellerProfile(matchedProfile)
  };
}
function logResellerApiCall(log) {
  const entry = {
    id: `log_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
    reseller_id: log.reseller_id,
    reseller_email: log.reseller_email,
    method: log.method,
    path: log.path,
    status_code: log.status_code,
    latency_ms: Math.round(log.latency_ms),
    ip: log.ip,
    user_agent: log.user_agent,
    error_message: log.error_message,
    created_at: (/* @__PURE__ */ new Date()).toISOString()
  };
  logsCache.unshift(entry);
  if (logsCache.length > 5e3) {
    logsCache = logsCache.slice(0, 5e3);
  }
  saveLogs();
  return entry;
}
var catalogCache = null;
var CATALOG_CACHE_TTL_MS = 2 * 60 * 1e3;
async function getResellerProductsCatalog(category, search) {
  if (catalogCache && Date.now() - catalogCache.timestamp < CATALOG_CACHE_TTL_MS) {
    let filtered2 = catalogCache.items;
    if (category) {
      filtered2 = filtered2.filter((i) => i.category === category);
    }
    if (search && search.trim()) {
      const q = search.trim().toLowerCase();
      filtered2 = filtered2.filter(
        (i) => i.name.toLowerCase().includes(q) || i.description.toLowerCase().includes(q) || i.category.toLowerCase().includes(q)
      );
    }
    return {
      success: true,
      products: filtered2,
      count: filtered2.length
    };
  }
  const items = [];
  const enabledCats = pricingConfig2.enabled_categories || { smm: true, accounts: true, numbers: true, marketplace: true };
  const disabledProducts = new Set((pricingConfig2.disabled_product_ids || []).map(String));
  const [smmSettled, cartlogsSettled, numbersSettled] = await Promise.allSettled([
    // 1. SMM Boosting Services
    enabledCats.smm && (!category || category === "smm" || category === "boosting") ? getFollowSPanelServices() : Promise.resolve(null),
    // 2. Social Accounts / Cartlogs
    enabledCats.accounts && (!category || category === "accounts" || category === "logs") ? getCartlogsProducts() : Promise.resolve(null),
    // 3. International Virtual Numbers
    enabledCats.numbers && (!category || category === "numbers" || category === "sms") ? getServices() : Promise.resolve(null)
  ]);
  if (smmSettled.status === "fulfilled" && smmSettled.value && smmSettled.value.success && Array.isArray(smmSettled.value.data)) {
    for (const s of smmSettled.value.data.slice(0, 50)) {
      const serviceId = s.service ?? s.id ?? s.service_id;
      if (disabledProducts.has(String(serviceId)) || disabledProducts.has(`smm_${serviceId}`)) {
        continue;
      }
      const standardRate = parseFloat(s.rate) || 1e3;
      const discountMultiplier = 1 - pricingConfig2.smm_discount_percent / 100;
      const resellerRate = Math.round(standardRate * discountMultiplier);
      items.push({
        id: `smm_${serviceId}`,
        name: s.name,
        category: "smm",
        category_label: "Social Media Boosting",
        description: `${s.category} - Min: ${s.min}, Max: ${s.max}`,
        price: resellerRate,
        original_price: standardRate,
        currency: "NGN",
        in_stock: true,
        rate_per_1000: resellerRate,
        min_quantity: s.min,
        max_quantity: s.max,
        fields_required: ["service_id", "link", "quantity"],
        sample_request: {
          category: "smm",
          service_id: serviceId,
          link: "https://instagram.com/your_profile",
          quantity: s.min || 100
        }
      });
    }
  }
  if (cartlogsSettled.status === "fulfilled" && cartlogsSettled.value && cartlogsSettled.value.success && Array.isArray(cartlogsSettled.value.data)) {
    for (const p of cartlogsSettled.value.data) {
      if (disabledProducts.has(String(p.id)) || disabledProducts.has(`acc_${p.id}`) || disabledProducts.has(`accounts_${p.id}`)) {
        continue;
      }
      const discountMultiplier = 1 - pricingConfig2.accounts_discount_percent / 100;
      const resellerPrice = Math.round(p.price * discountMultiplier);
      items.push({
        id: `acc_${p.id}`,
        name: p.title,
        category: "accounts",
        category_label: "Aged Social Accounts",
        description: `${p.category} | Stock: ${p.stock}`,
        price: resellerPrice,
        original_price: p.price,
        currency: "NGN",
        in_stock: p.in_stock && p.stock > 0,
        stock_count: p.stock,
        min_quantity: 1,
        max_quantity: p.stock || 10,
        fields_required: ["product_id", "quantity"],
        sample_request: {
          category: "accounts",
          product_id: p.id,
          quantity: 1
        }
      });
    }
  }
  if (numbersSettled.status === "fulfilled" && numbersSettled.value && numbersSettled.value.success) {
    const servicesList = numbersSettled.value.services || numbersSettled.value.data || [];
    if (Array.isArray(servicesList)) {
      for (const s of servicesList.slice(0, 30)) {
        const numId = s.id || s.code;
        if (disabledProducts.has(String(numId)) || disabledProducts.has(`num_${numId}`)) {
          continue;
        }
        const basePrice = s.price || 1200;
        const discountMultiplier = 1 - pricingConfig2.numbers_discount_percent / 100;
        const resellerPrice = Math.round(basePrice * discountMultiplier);
        items.push({
          id: `num_${numId}`,
          name: `${s.name} Virtual Number (USA/Global)`,
          category: "numbers",
          category_label: "International Numbers (SMS OTP)",
          description: `Receive instant SMS verification code for ${s.name}`,
          price: resellerPrice,
          original_price: basePrice,
          currency: "NGN",
          in_stock: s.available !== false,
          fields_required: ["country", "service"],
          sample_request: {
            category: "numbers",
            country: "0",
            // USA
            service: s.code || s.id
          }
        });
      }
    }
  }
  if (!category && items.length > 0) {
    catalogCache = {
      timestamp: Date.now(),
      items: [...items]
    };
  }
  let filtered = items;
  if (search && search.trim()) {
    const q = search.trim().toLowerCase();
    filtered = items.filter(
      (i) => i.name.toLowerCase().includes(q) || i.description.toLowerCase().includes(q) || i.category.toLowerCase().includes(q)
    );
  }
  return {
    success: true,
    products: filtered,
    count: filtered.length
  };
}
async function dispatchWebhookEvent(resellerId, event, payload) {
  const profile = resellersCache.get(String(resellerId));
  if (!profile || !profile.webhook_url || !profile.webhook_enabled) {
    return { success: false, error: "Webhook URL not configured or disabled." };
  }
  const bodyData = {
    id: `evt_${Date.now()}_${import_crypto3.default.randomBytes(6).toString("hex")}`,
    event,
    created_at: (/* @__PURE__ */ new Date()).toISOString(),
    data: payload
  };
  const bodyString = JSON.stringify(bodyData);
  const secret = profile.webhook_secret || "sp_whsec_default";
  const signature = import_crypto3.default.createHmac("sha256", secret).update(bodyString).digest("hex");
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 8e3);
    const response = await fetch(profile.webhook_url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "User-Agent": "SurestPlug-Webhook/1.0",
        "X-SurestPlug-Signature": `sha256=${signature}`,
        "X-SurestPlug-Event": event
      },
      body: bodyString,
      signal: controller.signal
    });
    clearTimeout(timeoutId);
    profile.webhook_last_status = response.status;
    profile.webhook_last_error = response.ok ? null : `HTTP ${response.status} - ${response.statusText}`;
    profile.webhook_last_dispatched_at = (/* @__PURE__ */ new Date()).toISOString();
    saveResellers();
    return {
      success: response.ok,
      status: response.status
    };
  } catch (err) {
    profile.webhook_last_status = 500;
    profile.webhook_last_error = err?.message || "Connection timeout or network failure";
    profile.webhook_last_dispatched_at = (/* @__PURE__ */ new Date()).toISOString();
    saveResellers();
    return {
      success: false,
      error: err?.message || "Webhook dispatch failed"
    };
  }
}
async function processResellerOrder(reseller, payload, idempotencyKeyHeader) {
  const idempotencyKey = idempotencyKeyHeader?.trim() || payload.idempotency_key?.trim();
  if (idempotencyKey) {
    const existing = ordersCache.find(
      (o) => String(o.reseller_id) === String(reseller.user_id) && o.idempotency_key === idempotencyKey
    );
    if (existing) {
      return {
        success: true,
        statusCode: 200,
        order: existing
      };
    }
  }
  const category = (payload.category || "").toLowerCase().trim();
  if (!["smm", "accounts", "numbers", "marketplace"].includes(category)) {
    return {
      success: false,
      statusCode: 400,
      code: "INVALID_CATEGORY",
      error: 'Invalid order category. Supported categories: "smm", "accounts", "numbers", "marketplace".'
    };
  }
  const enabledCats = pricingConfig2.enabled_categories || { smm: true, accounts: true, numbers: true, marketplace: true };
  if (enabledCats[category] === false) {
    return {
      success: false,
      statusCode: 403,
      code: "CATEGORY_DISABLED",
      error: `The "${category}" product category is currently disabled for Reseller API ordering by administration.`
    };
  }
  const disabledProducts = new Set((pricingConfig2.disabled_product_ids || []).map(String));
  const rawTargetId = String(payload.service_id || payload.product_id || payload.service || "");
  if (rawTargetId && (disabledProducts.has(rawTargetId) || disabledProducts.has(`${category}_${rawTargetId}`))) {
    return {
      success: false,
      statusCode: 403,
      code: "PRODUCT_DISABLED",
      error: `This product/service (ID: ${rawTargetId}) is currently disabled for Reseller API ordering by administration.`
    };
  }
  const minRequired = pricingConfig2.min_balance_threshold;
  if ((reseller.balance ?? 0) < minRequired) {
    return {
      success: false,
      statusCode: 403,
      code: "INSUFFICIENT_RESELLER_BALANCE",
      error: `Reseller API requires a minimum wallet balance of \u20A6${minRequired.toLocaleString()}. Current balance: \u20A6${(reseller.balance ?? 0).toLocaleString()}. Please top up your wallet.`
    };
  }
  let orderAmount = 0;
  let productName = "";
  let provider = "";
  let providerOrderId;
  let deliveryDetails = {};
  let status = "processing";
  const orderReference = `SP-API-${Date.now()}-${Math.random().toString(36).substring(2, 6).toUpperCase()}`;
  if (category === "smm") {
    const serviceId = payload.service_id;
    const link = payload.link;
    const quantity = Number(payload.quantity);
    if (!serviceId || !link || !quantity || quantity <= 0) {
      return {
        success: false,
        statusCode: 400,
        code: "MISSING_PARAMETERS",
        error: "SMM orders require service_id, link, and quantity."
      };
    }
    const servicesRes = await getFollowSPanelServices();
    let serviceRatePer1000 = 1e3;
    if (servicesRes.success && Array.isArray(servicesRes.data)) {
      const match = servicesRes.data.find((s) => String(s.service) === String(serviceId));
      if (match) {
        serviceRatePer1000 = parseFloat(match.rate) || 1e3;
        productName = match.name;
      }
    }
    const discountMultiplier = 1 - pricingConfig2.smm_discount_percent / 100;
    orderAmount = Math.max(1, Math.round(serviceRatePer1000 * quantity / 1e3 * discountMultiplier));
    productName = productName || `SMM Service #${serviceId}`;
    provider = "followspanel";
    if (reseller.balance < orderAmount) {
      return {
        success: false,
        statusCode: 400,
        code: "INSUFFICIENT_BALANCE",
        error: `Insufficient wallet balance. Required: \u20A6${orderAmount.toLocaleString()}, Available: \u20A6${reseller.balance.toLocaleString()}.`
      };
    }
    const providerResult = await createFollowSPanelOrder(serviceId, link, quantity);
    if (!providerResult.success || !providerResult.data?.order_id) {
      return {
        success: false,
        statusCode: 502,
        code: "PROVIDER_ERROR",
        error: providerResult.error || "Failed to place order with SMM upstream provider."
      };
    }
    providerOrderId = providerResult.data.order_id;
    deliveryDetails = {
      service_id: serviceId,
      link,
      quantity,
      provider_order_id: providerOrderId
    };
    status = "processing";
  } else if (category === "accounts") {
    const productId = payload.product_id;
    const quantity = Number(payload.quantity) || 1;
    if (!productId) {
      return {
        success: false,
        statusCode: 400,
        code: "MISSING_PARAMETERS",
        error: "Accounts orders require product_id."
      };
    }
    const productsRes = await getCartlogsProducts();
    let unitPrice = 3e3;
    if (productsRes.success && Array.isArray(productsRes.data)) {
      const match = productsRes.data.find((p) => String(p.id) === String(productId));
      if (match) {
        unitPrice = match.price;
        productName = match.title;
        if (!match.in_stock || match.stock < quantity) {
          return {
            success: false,
            statusCode: 400,
            code: "OUT_OF_STOCK",
            error: `Selected account is currently out of stock (Available: ${match.stock}).`
          };
        }
      }
    }
    const discountMultiplier = 1 - pricingConfig2.accounts_discount_percent / 100;
    orderAmount = Math.max(1, Math.round(unitPrice * quantity * discountMultiplier));
    productName = productName || `Account Product #${productId}`;
    provider = "cartlogs";
    if (reseller.balance < orderAmount) {
      return {
        success: false,
        statusCode: 400,
        code: "INSUFFICIENT_BALANCE",
        error: `Insufficient wallet balance. Required: \u20A6${orderAmount.toLocaleString()}, Available: \u20A6${reseller.balance.toLocaleString()}.`
      };
    }
    const providerResult = await createCartlogsOrder(
      productId,
      quantity,
      orderReference,
      idempotencyKey || orderReference,
      false
    );
    if (!providerResult.success) {
      return {
        success: false,
        statusCode: 502,
        code: "PROVIDER_ERROR",
        error: providerResult.error || "Failed to procure accounts from upstream provider."
      };
    }
    providerOrderId = providerResult.data?.cartlogs_order_id;
    deliveryDetails = {
      credentials: providerResult.data?.credentials || {},
      status: providerResult.data?.status || "completed"
    };
    status = "completed";
  } else if (category === "numbers") {
    const country = payload.country || "0";
    const service = payload.service || "wa";
    const discountMultiplier = 1 - pricingConfig2.numbers_discount_percent / 100;
    let standardPrice = 1350;
    try {
      const priceRes = await getPrice(country, service);
      if (priceRes && priceRes.price) {
        standardPrice = priceRes.price;
      }
    } catch (e) {
    }
    orderAmount = Math.round(standardPrice * discountMultiplier);
    productName = `Virtual Number (${service.toUpperCase()} - Country ${country})`;
    provider = "instantnums";
    if (reseller.balance < orderAmount) {
      return {
        success: false,
        statusCode: 400,
        code: "INSUFFICIENT_BALANCE",
        error: `Insufficient wallet balance. Required: \u20A6${orderAmount.toLocaleString()}, Available: \u20A6${reseller.balance.toLocaleString()}.`
      };
    }
    const providerResult = await purchaseNumber(country, service, {
      userId: String(reseller.user_id),
      userEmail: reseller.email,
      orderReference
    });
    if (!providerResult.success || !providerResult.phoneNumber) {
      return {
        success: false,
        statusCode: 502,
        code: "PROVIDER_ERROR",
        error: providerResult.error || "Failed to allocate virtual number from upstream SMS provider."
      };
    }
    providerOrderId = providerResult.orderId;
    deliveryDetails = {
      phone_number: providerResult.phoneNumber,
      order_id: providerResult.orderId,
      expires_at: providerResult.expiresAt
    };
    status = "processing";
  }
  const balanceBefore = reseller.balance;
  const balanceAfter = Number((balanceBefore - orderAmount).toFixed(2));
  const key = String(reseller.user_id);
  const liveProfile = resellersCache.get(key);
  if (liveProfile) {
    liveProfile.balance = balanceAfter;
    liveProfile.total_orders = (liveProfile.total_orders || 0) + 1;
    liveProfile.total_spent = Number(((liveProfile.total_spent || 0) + orderAmount).toFixed(2));
    liveProfile.updated_at = (/* @__PURE__ */ new Date()).toISOString();
    if (balanceAfter < minRequired) {
      liveProfile.is_eligible = false;
    }
    resellersCache.set(key, liveProfile);
    saveResellers();
  }
  const newOrder = {
    id: `res_ord_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
    reseller_id: reseller.user_id,
    reseller_email: reseller.email,
    reseller_name: reseller.full_name,
    idempotency_key: idempotencyKey || orderReference,
    category,
    service_id: payload.service_id,
    product_id: payload.product_id,
    product_name: productName,
    quantity: payload.quantity || 1,
    amount: orderAmount,
    currency: "NGN",
    balance_before: balanceBefore,
    balance_after: balanceAfter,
    status,
    provider,
    provider_order_id: providerOrderId,
    order_reference: orderReference,
    phone_number: deliveryDetails.phone_number,
    credentials: deliveryDetails.credentials,
    details: deliveryDetails,
    created_at: (/* @__PURE__ */ new Date()).toISOString(),
    updated_at: (/* @__PURE__ */ new Date()).toISOString()
  };
  ordersCache.unshift(newOrder);
  saveOrders();
  dispatchWebhookEvent(reseller.user_id, "order.created", {
    order_reference: newOrder.order_reference,
    category: newOrder.category,
    product_name: newOrder.product_name,
    amount: newOrder.amount,
    currency: newOrder.currency,
    status: newOrder.status,
    details: deliveryDetails,
    created_at: newOrder.created_at
  }).catch(() => {
  });
  return {
    success: true,
    statusCode: 201,
    order: newOrder
  };
}
function getResellerOrdersList(resellerId, category, status, limit = 50) {
  let list = ordersCache.filter((o) => String(o.reseller_id) === String(resellerId));
  if (category && category !== "all") {
    list = list.filter((o) => o.category === category);
  }
  if (status && status !== "all") {
    list = list.filter((o) => o.status === status);
  }
  return {
    success: true,
    orders: list.slice(0, limit),
    total: list.length
  };
}
async function getResellerOrderById(resellerId, orderIdOrRef) {
  const order = ordersCache.find(
    (o) => String(o.reseller_id) === String(resellerId) && (o.id === orderIdOrRef || o.order_reference === orderIdOrRef || String(o.provider_order_id) === orderIdOrRef)
  );
  if (!order) {
    return { success: false, error: "Order not found." };
  }
  if (order.status === "processing") {
    if (order.category === "smm" && order.provider_order_id) {
      try {
        const smmStatus = await getFollowSPanelOrderStatus(order.provider_order_id);
        if (smmStatus.success && smmStatus.data) {
          order.details = { ...order.details, ...smmStatus.data };
          if (smmStatus.data.status === "Completed") order.status = "completed";
          if (smmStatus.data.status === "Canceled") order.status = "cancelled";
          saveOrders();
        }
      } catch (e) {
      }
    } else if (order.category === "numbers" && order.provider_order_id) {
      try {
        const numStatus = await getOrderStatus(String(order.provider_order_id));
        if (numStatus && numStatus.success) {
          if (numStatus.sms) {
            order.sms_code = numStatus.sms;
            order.sms_text = numStatus.fullSms || void 0;
            order.status = "completed";
            saveOrders();
            dispatchWebhookEvent(order.reseller_id, "order.completed", {
              order_reference: order.order_reference,
              category: "numbers",
              phone_number: order.phone_number,
              sms_code: order.sms_code,
              sms_text: order.sms_text
            }).catch(() => {
            });
          }
        }
      } catch (e) {
      }
    }
  }
  return { success: true, order };
}
async function cancelResellerOrder(resellerId, orderIdOrRef) {
  const order = ordersCache.find(
    (o) => String(o.reseller_id) === String(resellerId) && (o.id === orderIdOrRef || o.order_reference === orderIdOrRef)
  );
  if (!order) {
    return { success: false, error: "Order not found." };
  }
  if (order.status !== "processing" && order.status !== "pending") {
    return { success: false, error: `Cannot cancel order with status: ${order.status}` };
  }
  if (order.category === "numbers" && order.provider_order_id) {
    const cancelRes = await cancelOrder(String(order.provider_order_id));
    if (!cancelRes.success) {
      return { success: false, error: cancelRes.error || "Upstream provider could not cancel number." };
    }
  }
  const refundAmount = order.amount;
  const key = String(resellerId);
  const profile = resellersCache.get(key);
  if (profile) {
    const updatedBalance = Number(((profile.balance || 0) + refundAmount).toFixed(2));
    profile.balance = updatedBalance;
    if (updatedBalance >= pricingConfig2.min_balance_threshold) {
      profile.is_eligible = true;
    }
    profile.updated_at = (/* @__PURE__ */ new Date()).toISOString();
    resellersCache.set(key, profile);
    saveResellers();
  }
  order.status = "cancelled";
  order.balance_after = Number(((order.balance_after || 0) + refundAmount).toFixed(2));
  order.updated_at = (/* @__PURE__ */ new Date()).toISOString();
  saveOrders();
  dispatchWebhookEvent(resellerId, "order.cancelled", {
    order_reference: order.order_reference,
    refund_amount: refundAmount,
    balance: profile?.balance
  }).catch(() => {
  });
  return {
    success: true,
    order,
    refundAmount
  };
}
function getResellerApiLogs(resellerId, limit = 50) {
  return logsCache.filter((l) => String(l.reseller_id) === String(resellerId)).slice(0, limit);
}
function getAllResellersForAdmin() {
  const list = [];
  let activeKeysCount = 0;
  let totalOrdersCount = 0;
  let totalVolumeAmount = 0;
  resellersCache.forEach((profile) => {
    list.push(sanitizeResellerProfile(profile));
    if (profile.has_api_key && profile.status === "active") activeKeysCount++;
    totalOrdersCount += profile.total_orders || 0;
    totalVolumeAmount += profile.total_spent || 0;
  });
  const recentLogs = logsCache.slice(0, 500);
  const avgLatency = recentLogs.length > 0 ? Math.round(recentLogs.reduce((acc, l) => acc + (l.latency_ms || 0), 0) / recentLogs.length) : 145;
  return {
    resellers: list.sort((a, b) => (b.total_orders || 0) - (a.total_orders || 0)),
    stats: {
      total_resellers: list.length,
      active_keys: activeKeysCount,
      total_orders: totalOrdersCount,
      total_volume: Math.round(totalVolumeAmount),
      avg_latency_ms: avgLatency
    }
  };
}
function adminToggleResellerStatus(userId, status) {
  const key = String(userId);
  const profile = resellersCache.get(key);
  if (!profile) {
    return { success: false, error: "Reseller profile not found." };
  }
  profile.status = status;
  profile.updated_at = (/* @__PURE__ */ new Date()).toISOString();
  resellersCache.set(key, profile);
  saveResellers();
  return { success: true, profile: sanitizeResellerProfile(profile) };
}
function adminRevokeResellerKey(userId) {
  return revokeResellerKey(userId);
}
function getAdminSystemLogs(limit = 100, statusFilter) {
  let logs = logsCache;
  if (statusFilter && statusFilter !== "all") {
    if (statusFilter === "2xx") logs = logs.filter((l) => l.status_code >= 200 && l.status_code < 300);
    else if (statusFilter === "4xx") logs = logs.filter((l) => l.status_code >= 400 && l.status_code < 500);
    else if (statusFilter === "5xx") logs = logs.filter((l) => l.status_code >= 500);
  }
  return logs.slice(0, limit);
}
function getResellerPricing() {
  return { ...pricingConfig2 };
}
function updateResellerPricing(newConfig) {
  pricingConfig2 = {
    ...pricingConfig2,
    ...newConfig,
    min_balance_threshold: 5e3
    // locked strictly at ₦5,000 per user rule
  };
  saveConfig();
  return { ...pricingConfig2 };
}

// server.ts
try {
  import_dotenv2.default.config();
} catch (e) {
}
process.on("uncaughtException", (err) => {
  console.error("[Process Error] Uncaught Exception:", err?.message || err);
});
process.on("unhandledRejection", (reason) => {
  console.error("[Process Error] Unhandled Rejection:", reason);
});
async function startServer() {
  const app = (0, import_express.default)();
  const PORT = parseInt(process.env.PORT || "3000", 10);
  app.use(import_express.default.json());
  app.get(["/health", "/api/health"], (req, res) => {
    res.status(200).json({
      status: "ok",
      service: "surest-plug-digital-marketplace",
      port: PORT,
      timestamp: (/* @__PURE__ */ new Date()).toISOString()
    });
  });
  app.get("/api/smm/services", async (req, res) => {
    try {
      const result = await getFollowSPanelServices();
      res.status(result.success ? 200 : 503).json(result);
    } catch (err) {
      console.error("Error in /api/smm/services:", err?.message || err);
      res.status(500).json({
        success: false,
        error: err?.message || "Failed to retrieve social media boosting services."
      });
    }
  });
  app.post(["/api/smm/order", "/api/admin/followspanel/order"], async (req, res) => {
    try {
      const { serviceId, link, quantity } = req.body || {};
      const result = await createFollowSPanelOrder(serviceId, link, quantity);
      res.status(result.success ? 200 : 400).json(result);
    } catch (err) {
      console.error("Error in order endpoint:", err?.message || err);
      res.status(500).json({
        success: false,
        error: err?.message || "Failed to process boosting order with provider."
      });
    }
  });
  app.get("/api/smm/status", async (req, res) => {
    try {
      const orderId = req.query.order;
      const result = await getFollowSPanelOrderStatus(orderId);
      if (result.success && result.data) {
        return res.status(200).json({
          success: true,
          data: {
            status: result.data.status || "In progress",
            start_count: result.data.start_count || "0",
            remains: result.data.remains || "0"
          }
        });
      }
      res.status(400).json(result);
    } catch (err) {
      console.error("Error in /api/smm/status:", err?.message || err);
      res.status(500).json({
        success: false,
        error: err?.message || "Failed to retrieve boosting order status."
      });
    }
  });
  app.post("/api/smm/status", async (req, res) => {
    try {
      const { orderId, order } = req.body || {};
      const result = await getFollowSPanelOrderStatus(orderId || order);
      if (result.success && result.data) {
        return res.status(200).json({
          success: true,
          data: {
            status: result.data.status || "In progress",
            start_count: result.data.start_count || "0",
            remains: result.data.remains || "0"
          }
        });
      }
      res.status(400).json(result);
    } catch (err) {
      console.error("Error in POST /api/smm/status:", err?.message || err);
      res.status(500).json({
        success: false,
        error: err?.message || "Failed to retrieve boosting order status."
      });
    }
  });
  app.get("/api/smm/balance", async (req, res) => {
    try {
      const result = await getFollowSPanelBalance();
      res.status(result.success ? 200 : 503).json(result);
    } catch (err) {
      console.error("Error in /api/smm/balance:", err?.message || err);
      res.status(500).json({
        success: false,
        error: err?.message || "Failed to query FollowSPanel provider balance."
      });
    }
  });
  app.get("/api/admin/followspanel/config", (req, res) => {
    try {
      const config = getFollowSPanelConfigStatus();
      res.json({ success: true, data: config });
    } catch (err) {
      res.status(500).json({ success: false, error: "Failed to read FollowSPanel configuration status." });
    }
  });
  app.post("/api/admin/followspanel/test", async (req, res) => {
    try {
      const result = await testFollowSPanelConnection();
      res.status(result.success ? 200 : 400).json(result);
    } catch (err) {
      res.status(500).json({
        success: false,
        error: "Unable to test API connection with FollowSPanel."
      });
    }
  });
  app.get("/api/admin/followspanel/test", async (req, res) => {
    try {
      const result = await testFollowSPanelConnection();
      res.status(result.success ? 200 : 400).json(result);
    } catch (err) {
      res.status(500).json({
        success: false,
        error: "Unable to test API connection with FollowSPanel."
      });
    }
  });
  app.get("/api/admin/followspanel/balance", async (req, res) => {
    try {
      const result = await getFollowSPanelBalance();
      res.status(result.success ? 200 : 503).json(result);
    } catch (err) {
      res.status(500).json({
        success: false,
        error: "Failed to retrieve FollowSPanel balance."
      });
    }
  });
  app.get("/api/admin/followspanel/services", async (req, res) => {
    try {
      const result = await getFollowSPanelServices();
      res.status(result.success ? 200 : 503).json(result);
    } catch (err) {
      res.status(500).json({
        success: false,
        error: "Failed to retrieve FollowSPanel services catalog."
      });
    }
  });
  app.post("/api/admin/followspanel/status", async (req, res) => {
    try {
      const { orderId } = req.body || {};
      const result = await getFollowSPanelOrderStatus(orderId);
      res.status(result.success ? 200 : 400).json(result);
    } catch (err) {
      res.status(500).json({
        success: false,
        error: "Failed to query FollowSPanel order status."
      });
    }
  });
  app.post("/api/admin/followspanel/multi-status", async (req, res) => {
    try {
      const { orderIds } = req.body || {};
      if (!Array.isArray(orderIds) || orderIds.length === 0) {
        return res.status(400).json({ success: false, error: "orderIds array is required." });
      }
      const result = await getFollowSPanelMultipleOrderStatus(orderIds);
      res.status(result.success ? 200 : 400).json(result);
    } catch (err) {
      res.status(500).json({
        success: false,
        error: "Failed to query FollowSPanel order statuses."
      });
    }
  });
  app.get("/api/cartlogs/categories", async (req, res) => {
    try {
      const result = await getCartlogsCategories(false);
      res.status(result.success ? 200 : 503).json(result);
    } catch (err) {
      res.status(500).json({
        success: false,
        error: "Categories are temporarily unavailable. Please try again later."
      });
    }
  });
  app.get("/api/cartlogs/products", async (req, res) => {
    try {
      const category = req.query.category;
      const result = await getCartlogsProducts(category, false);
      res.status(result.success ? 200 : 503).json(result);
    } catch (err) {
      res.status(500).json({
        success: false,
        error: "Account products are temporarily unavailable. Please try again later."
      });
    }
  });
  app.post("/api/cartlogs/order", async (req, res) => {
    try {
      const { productId, quantity, orderReference, idempotencyKey } = req.body || {};
      if (!productId || !orderReference) {
        return res.status(400).json({
          success: false,
          error: "Product ID and Order Reference are required."
        });
      }
      const result = await createCartlogsOrder(
        productId,
        Number(quantity) || 1,
        orderReference,
        idempotencyKey,
        false
      );
      if (result.success && result.data) {
        return res.status(200).json({
          success: true,
          data: {
            status: result.data.status,
            credentials: result.data.credentials
          }
        });
      }
      res.status(result.code ? Number(result.code) : 400).json(result);
    } catch (err) {
      res.status(500).json({
        success: false,
        error: "Order could not be processed at this time. Please try again."
      });
    }
  });
  app.get("/api/cartlogs/status", async (req, res) => {
    try {
      const orderId = req.query.orderId;
      const result = await getCartlogsOrderStatus(orderId, false);
      res.status(result.success ? 200 : 400).json(result);
    } catch (err) {
      res.status(500).json({
        success: false,
        error: "Unable to query order status."
      });
    }
  });
  app.post("/api/cartlogs/webhook", (req, res) => {
    try {
      const signature = req.headers["x-cartlogs-signature"];
      const rawBody = typeof req.body === "string" ? req.body : JSON.stringify(req.body);
      if (process.env.CARTLOGS_WEBHOOK_SECRET) {
        const isValid = verifyCartlogsWebhookSignature(rawBody, signature);
        if (!isValid) {
          return res.status(401).json({ success: false, error: "Invalid webhook signature." });
        }
      }
      const payload = req.body || {};
      const event = payload.event || payload.type;
      const data = payload.data || payload;
      console.log(`[Cartlogs Webhook] Event: ${event}, Order ID: ${data?.id || data?.order_id}`);
      res.status(200).json({ received: true, event });
    } catch (err) {
      res.status(500).json({ success: false, error: "Webhook processing error." });
    }
  });
  app.post("/api/admin/cartlogs/test", async (req, res) => {
    try {
      const result = await testCartlogsConnection();
      res.status(result.success ? 200 : 400).json(result);
    } catch (err) {
      res.status(500).json({
        success: false,
        error: "Failed to execute Cartlogs connection test."
      });
    }
  });
  app.get("/api/admin/cartlogs/categories", async (req, res) => {
    try {
      const result = await getCartlogsCategories(true);
      res.status(result.success ? 200 : 503).json(result);
    } catch (err) {
      res.status(500).json({
        success: false,
        error: "Failed to fetch categories catalog from Cartlogs."
      });
    }
  });
  app.get("/api/admin/cartlogs/products", async (req, res) => {
    try {
      const category = req.query.category;
      const result = await getCartlogsProducts(category, true);
      res.status(result.success ? 200 : 503).json(result);
    } catch (err) {
      res.status(500).json({
        success: false,
        error: "Failed to fetch products from Cartlogs."
      });
    }
  });
  app.get("/api/admin/cartlogs/capabilities", async (req, res) => {
    try {
      const result = await inspectCartlogsOtpCapabilities();
      res.status(200).json(result);
    } catch (err) {
      res.status(500).json({
        supported: false,
        categories: [],
        message: "Failed to inspect capabilities."
      });
    }
  });
  app.post("/api/paystack/initialize", async (req, res) => {
    try {
      const { amount, email, userId, name } = req.body || {};
      const amountNum = Number(amount);
      if (!amount || isNaN(amountNum) || amountNum <= 0) {
        return res.status(400).json({
          success: false,
          error: "Please enter a valid deposit amount."
        });
      }
      if (amountNum < 1e3) {
        return res.status(400).json({
          success: false,
          error: "Minimum funding amount is \u20A61,000."
        });
      }
      const result = await initializePaystackTransaction({
        amount: amountNum,
        email,
        userId,
        name
      });
      res.status(result.success ? 200 : 400).json(result);
    } catch (err) {
      res.status(500).json({
        success: false,
        error: "Unable to initialize Paystack payment. Please try again."
      });
    }
  });
  app.post("/api/paystack/verify", async (req, res) => {
    try {
      const { reference, amount, userId, email } = req.body || {};
      if (!reference) {
        return res.status(400).json({
          success: false,
          error: "Payment reference is required."
        });
      }
      const result = await verifyPaystackTransaction(
        reference,
        amount ? Number(amount) : void 0,
        userId,
        email
      );
      res.status(result.success ? 200 : 400).json(result);
    } catch (err) {
      res.status(500).json({
        success: false,
        error: "Unable to verify payment with Paystack."
      });
    }
  });
  app.post("/api/paystack/webhook", (req, res) => {
    try {
      const signature = req.headers["x-paystack-signature"];
      const rawBody = typeof req.body === "string" ? req.body : JSON.stringify(req.body);
      if (process.env.PAYSTACK_SECRET_KEY) {
        const isValid = verifyPaystackWebhookSignature(rawBody, signature);
        if (!isValid) {
          return res.status(401).json({ success: false, error: "Invalid Paystack webhook signature." });
        }
      }
      const payload = req.body || {};
      const event = payload.event;
      const data = payload.data || {};
      if (event === "charge.success") {
        const reference = (data.reference || "").trim();
        const amountKobo = Number(data.amount || 0);
        const amountNaira = amountKobo / 100;
        const customerEmail = data.customer?.email;
        const userId = data.metadata?.userId || data.metadata?.user_id;
        if (reference) {
          if (isReferenceAlreadyProcessed(reference)) {
            console.log(`[Paystack Webhook] Reference ${reference} already processed. Duplicate processing prevented.`);
            return res.status(200).json({ status: "success", received: true, message: "Already processed" });
          }
          markReferenceAsProcessed(reference, userId || "webhook", amountNaira, "success");
          console.log(`[Paystack Webhook] Successfully recorded verified charge for ${customerEmail} (\u20A6${amountNaira}, Ref: ${reference})`);
        }
      }
      res.status(200).json({ status: "success", received: true });
    } catch (err) {
      res.status(500).json({ success: false, error: "Webhook processing error." });
    }
  });
  app.get("/api/paystack/config", (req, res) => {
    res.status(200).json({
      publicKey: process.env.VITE_PAYSTACK_PUBLIC_KEY || "pk_test_c6a989fa162d6563a2e53015cd6cf15570f68d8f"
    });
  });
  app.get("/api/international-numbers/countries", async (req, res) => {
    try {
      const result = await getCountries();
      res.status(result.success ? 200 : 503).json(result);
    } catch (err) {
      res.status(500).json({ success: false, countries: [], error: "Failed to load countries" });
    }
  });
  app.get("/api/international-numbers/services", async (req, res) => {
    try {
      const country = req.query.country || req.query.countryId ? String(req.query.country || req.query.countryId).trim() : void 0;
      const result = await getServices(country);
      res.status(result.success ? 200 : 503).json(result);
    } catch (err) {
      res.status(500).json({ success: false, services: [], error: "Failed to load services" });
    }
  });
  app.get("/api/international-numbers/stock", async (req, res) => {
    try {
      const country = String(req.query.country || req.query.countryId || "1").trim();
      const service = String(req.query.service || req.query.serviceId || "").trim();
      if (!service) {
        return res.status(400).json({ success: false, stock: null, status: "INVALID_RESPONSE", error: "Service is required" });
      }
      const result = await getStock(country, service);
      res.status(result.success ? 200 : 502).json(result);
    } catch (err) {
      res.status(500).json({ success: false, stock: null, status: "PROVIDER_UNAVAILABLE", error: err?.message || "Stock lookup failed" });
    }
  });
  app.get("/api/international-numbers/price", async (req, res) => {
    try {
      const country = String(req.query.country || req.query.countryId || "1").trim();
      const service = String(req.query.service || req.query.serviceId || "").trim();
      if (!service) {
        return res.status(400).json({ success: false, price: 1352, error: "Service is required" });
      }
      const result = await getPrice(country, service);
      res.status(result.success ? 200 : 502).json(result);
    } catch (err) {
      res.status(500).json({ success: false, price: 1352, error: err?.message || "Price lookup failed" });
    }
  });
  app.get("/api/international-numbers/availability", async (req, res) => {
    try {
      const country = String(req.query.country || req.query.countryId || "1").trim();
      const service = String(req.query.service || req.query.serviceId || "").trim();
      if (!service) {
        return res.status(400).json({ success: false, available: false, stock: null, price: 1352, status: "INVALID_RESPONSE", error: "Service is required" });
      }
      const result = await getAvailability(country, service);
      res.status(result.success ? 200 : 502).json(result);
    } catch (err) {
      res.status(500).json({ success: false, available: false, stock: null, price: 1352, status: "PROVIDER_UNAVAILABLE", error: err?.message || "Availability lookup failed" });
    }
  });
  app.post("/api/international-numbers/purchase", async (req, res) => {
    try {
      const { country, service, countryId, serviceId, userId, userEmail, orderReference } = req.body || {};
      const finalCountry = String(country || countryId || "1").trim();
      const finalService = String(service || serviceId || "").trim();
      if (!finalService) {
        return res.status(400).json({ success: false, error: "Service is required for purchase" });
      }
      const result = await purchaseNumber(finalCountry, finalService, {
        userId: userId ? String(userId) : void 0,
        userEmail: userEmail ? String(userEmail) : void 0,
        orderReference: orderReference ? String(orderReference) : void 0
      });
      res.status(result.success ? 200 : 400).json(result);
    } catch (err) {
      res.status(500).json({ success: false, error: "Failed to reserve number" });
    }
  });
  app.get(["/api/international-numbers/order/:orderId", "/api/international-numbers/sms/:orderId"], async (req, res) => {
    try {
      const { orderId } = req.params;
      if (!orderId) {
        return res.status(400).json({ success: false, error: "Order ID is required" });
      }
      const result = await getOrderStatus(orderId);
      res.status(result.success ? 200 : 400).json(result);
    } catch (err) {
      res.status(500).json({ success: false, error: "Failed to check order status" });
    }
  });
  app.get("/api/international-numbers/status", async (req, res) => {
    try {
      const orderId = String(req.query.order_id || req.query.orderId || req.query.id || "").trim();
      if (!orderId) {
        return res.status(400).json({ success: false, error: "Order ID is required" });
      }
      const result = await getOrderStatus(orderId);
      res.status(result.success ? 200 : 400).json(result);
    } catch (err) {
      res.status(500).json({ success: false, error: "Failed to check order status" });
    }
  });
  app.post(["/api/international-numbers/order/:orderId/cancel", "/api/international-numbers/sms/:orderId/cancel"], async (req, res) => {
    try {
      const { orderId } = req.params;
      if (!orderId) {
        return res.status(400).json({ success: false, error: "Order ID is required" });
      }
      const result = await cancelOrder(orderId);
      res.status(result.success ? 200 : 400).json(result);
    } catch (err) {
      res.status(500).json({ success: false, error: "Failed to cancel order" });
    }
  });
  app.post("/api/international-numbers/cancel", async (req, res) => {
    try {
      const orderId = String(req.body?.order_id || req.body?.orderId || req.body?.id || "").trim();
      if (!orderId) {
        return res.status(400).json({ success: false, error: "Order ID is required" });
      }
      const result = await cancelOrder(orderId);
      res.status(result.success ? 200 : 400).json(result);
    } catch (err) {
      res.status(500).json({ success: false, error: "Failed to cancel order" });
    }
  });
  app.get("/api/international-numbers/orders", (req, res) => {
    try {
      const userId = req.query.user_id ? String(req.query.user_id) : void 0;
      const userEmail = req.query.user_email ? String(req.query.user_email) : void 0;
      const orders = getServerOrders(userId, userEmail);
      res.json({ success: true, orders });
    } catch (err) {
      res.status(500).json({ success: false, error: "Failed to retrieve orders from backend" });
    }
  });
  app.post("/api/international-numbers/record-order", (req, res) => {
    try {
      const record = recordServerOrder(req.body || {});
      res.json({ success: true, order: record });
    } catch (err) {
      res.status(500).json({ success: false, error: "Failed to record order" });
    }
  });
  app.get(["/api/international-numbers/balance", "/api/international-numbers/admin/balance"], async (req, res) => {
    try {
      const result = await getBalance();
      res.status(result.success ? 200 : 503).json(result);
    } catch (err) {
      res.status(500).json({ success: false, error: "Failed to fetch balance" });
    }
  });
  app.get("/api/international-numbers/admin/pricing-config", (req, res) => {
    res.json({ success: true, data: getPricingConfig() });
  });
  app.post("/api/international-numbers/admin/pricing-config", (req, res) => {
    const updated = updatePricingConfig(req.body || {});
    res.json({ success: true, data: updated });
  });
  app.post("/api/international-numbers/process-expired", async (req, res) => {
    try {
      const result = await processExpiredOrders();
      res.json({ success: true, result });
    } catch (err) {
      res.status(500).json({ success: false, error: err?.message || "Failed to process expired orders" });
    }
  });
  const rateLimitMap = /* @__PURE__ */ new Map();
  const RATE_LIMIT_WINDOW_MS = 60 * 1e3;
  const RATE_LIMIT_MAX_REQUESTS = 60;
  function checkRateLimit(identifier) {
    const now = Date.now();
    let record = rateLimitMap.get(identifier);
    if (!record || now > record.resetTime) {
      record = { count: 1, resetTime: now + RATE_LIMIT_WINDOW_MS };
      rateLimitMap.set(identifier, record);
      return {
        allowed: true,
        remaining: RATE_LIMIT_MAX_REQUESTS - 1,
        resetTime: record.resetTime,
        retryAfter: 0
      };
    }
    record.count++;
    const remaining = Math.max(0, RATE_LIMIT_MAX_REQUESTS - record.count);
    const retryAfter = Math.ceil((record.resetTime - now) / 1e3);
    return {
      allowed: record.count <= RATE_LIMIT_MAX_REQUESTS,
      remaining,
      resetTime: record.resetTime,
      retryAfter
    };
  }
  async function handleV1Auth(req, res, next) {
    const startTime = Date.now();
    const authHeader = req.headers.authorization || req.headers["x-api-key"];
    const rateLimitKey = authHeader || req.ip || "anonymous";
    const rateLimit = checkRateLimit(rateLimitKey);
    res.setHeader("X-RateLimit-Limit", RATE_LIMIT_MAX_REQUESTS);
    res.setHeader("X-RateLimit-Remaining", rateLimit.remaining);
    res.setHeader("X-RateLimit-Reset", Math.ceil(rateLimit.resetTime / 1e3));
    if (!rateLimit.allowed) {
      res.setHeader("Retry-After", rateLimit.retryAfter);
      const latency = Date.now() - startTime;
      logResellerApiCall({
        reseller_id: "rate_limited",
        reseller_email: "unknown",
        method: req.method,
        path: req.originalUrl || req.path,
        status_code: 429,
        latency_ms: latency,
        ip: req.ip || req.socket.remoteAddress || "127.0.0.1",
        user_agent: req.headers["user-agent"],
        error_message: "Rate limit exceeded"
      });
      return res.status(429).json({
        success: false,
        code: "RATE_LIMIT_EXCEEDED",
        error: `Too many requests. Rate limit is ${RATE_LIMIT_MAX_REQUESTS} requests per minute. Please retry after ${rateLimit.retryAfter} seconds.`
      });
    }
    const isInfoRoute = req.path.endsWith("/profile") || req.path.endsWith("/me") || req.path.endsWith("/balance");
    const authRes = authenticateResellerToken(authHeader, { allowBelowThreshold: isInfoRoute });
    if (!authRes.authenticated || !authRes.reseller) {
      const latency = Date.now() - startTime;
      logResellerApiCall({
        reseller_id: "unauthenticated",
        reseller_email: "unknown",
        method: req.method,
        path: req.originalUrl || req.path,
        status_code: authRes.statusCode || 401,
        latency_ms: latency,
        ip: req.ip || req.socket.remoteAddress || "127.0.0.1",
        user_agent: req.headers["user-agent"],
        error_message: authRes.error
      });
      return res.status(authRes.statusCode || 401).json({
        success: false,
        code: authRes.code || "UNAUTHORIZED",
        error: authRes.error
      });
    }
    req.reseller = authRes.reseller;
    req.apiStartTime = startTime;
    next();
  }
  app.get(["/api/v1/profile", "/api/v1/me"], handleV1Auth, (req, res) => {
    const reseller = req.reseller;
    const latency = Date.now() - (req.apiStartTime || Date.now());
    logResellerApiCall({
      reseller_id: reseller.user_id,
      reseller_email: reseller.email,
      method: req.method,
      path: req.path,
      status_code: 200,
      latency_ms: latency,
      ip: req.ip || "127.0.0.1",
      user_agent: req.headers["user-agent"]
    });
    res.json({
      success: true,
      data: reseller
    });
  });
  app.get("/api/v1/balance", handleV1Auth, (req, res) => {
    const reseller = req.reseller;
    const latency = Date.now() - (req.apiStartTime || Date.now());
    logResellerApiCall({
      reseller_id: reseller.user_id,
      reseller_email: reseller.email,
      method: req.method,
      path: req.path,
      status_code: 200,
      latency_ms: latency,
      ip: req.ip || "127.0.0.1"
    });
    const minRequired = reseller.min_balance_threshold || 5e3;
    const isEligible = (reseller.balance ?? 0) >= minRequired;
    res.json({
      success: true,
      balance: reseller.balance,
      currency: reseller.currency || "NGN",
      min_required_balance: minRequired,
      is_eligible: isEligible,
      api_access: isEligible ? "active" : "temporarily_suspended",
      notice: isEligible ? "Reseller API access is active and fully functional." : `Wallet balance is below \u20A6${minRequired.toLocaleString()}. API order placement is temporarily suspended. Fund your wallet with at least \u20A6${Math.max(0, minRequired - (reseller.balance || 0)).toLocaleString()} to restore order placement.`
    });
  });
  app.get(["/api/v1/products", "/api/v1/services"], handleV1Auth, async (req, res) => {
    const reseller = req.reseller;
    const { category, search } = req.query;
    const result = await getResellerProductsCatalog(category, search);
    const latency = Date.now() - (req.apiStartTime || Date.now());
    logResellerApiCall({
      reseller_id: reseller.user_id,
      reseller_email: reseller.email,
      method: req.method,
      path: req.path,
      status_code: 200,
      latency_ms: latency,
      ip: req.ip || "127.0.0.1"
    });
    res.json(result);
  });
  app.get("/api/v1/products/:id", handleV1Auth, async (req, res) => {
    const reseller = req.reseller;
    const productId = req.params.id;
    const catalog = await getResellerProductsCatalog();
    const product = catalog.products.find((p) => String(p.id) === String(productId));
    const latency = Date.now() - (req.apiStartTime || Date.now());
    if (!product) {
      logResellerApiCall({
        reseller_id: reseller.user_id,
        reseller_email: reseller.email,
        method: req.method,
        path: req.path,
        status_code: 404,
        latency_ms: latency,
        ip: req.ip || "127.0.0.1",
        error_message: "Product not found"
      });
      return res.status(404).json({ success: false, error: "Product not found in reseller catalog." });
    }
    logResellerApiCall({
      reseller_id: reseller.user_id,
      reseller_email: reseller.email,
      method: req.method,
      path: req.path,
      status_code: 200,
      latency_ms: latency,
      ip: req.ip || "127.0.0.1"
    });
    res.json({ success: true, product });
  });
  app.post("/api/v1/orders", handleV1Auth, async (req, res) => {
    const reseller = req.reseller;
    const idempotencyKey = req.headers["idempotency-key"] || req.body?.idempotency_key;
    try {
      const result = await processResellerOrder(reseller, req.body || {}, idempotencyKey);
      const latency = Date.now() - (req.apiStartTime || Date.now());
      logResellerApiCall({
        reseller_id: reseller.user_id,
        reseller_email: reseller.email,
        method: req.method,
        path: req.path,
        status_code: result.statusCode,
        latency_ms: latency,
        ip: req.ip || "127.0.0.1",
        error_message: result.error
      });
      res.status(result.statusCode).json(result);
    } catch (err) {
      const latency = Date.now() - (req.apiStartTime || Date.now());
      logResellerApiCall({
        reseller_id: reseller.user_id,
        reseller_email: reseller.email,
        method: req.method,
        path: req.path,
        status_code: 500,
        latency_ms: latency,
        ip: req.ip || "127.0.0.1",
        error_message: err?.message || "Server order exception"
      });
      res.status(500).json({ success: false, error: "Internal order processing error." });
    }
  });
  app.get("/api/v1/orders", handleV1Auth, (req, res) => {
    const reseller = req.reseller;
    const { category, status, limit } = req.query;
    const list = getResellerOrdersList(
      reseller.user_id,
      category,
      status,
      Number(limit) || 50
    );
    const latency = Date.now() - (req.apiStartTime || Date.now());
    logResellerApiCall({
      reseller_id: reseller.user_id,
      reseller_email: reseller.email,
      method: req.method,
      path: req.path,
      status_code: 200,
      latency_ms: latency,
      ip: req.ip || "127.0.0.1"
    });
    res.json(list);
  });
  app.get("/api/v1/orders/:id", handleV1Auth, async (req, res) => {
    const reseller = req.reseller;
    const result = await getResellerOrderById(reseller.user_id, req.params.id);
    const latency = Date.now() - (req.apiStartTime || Date.now());
    logResellerApiCall({
      reseller_id: reseller.user_id,
      reseller_email: reseller.email,
      method: req.method,
      path: req.path,
      status_code: result.success ? 200 : 404,
      latency_ms: latency,
      ip: req.ip || "127.0.0.1",
      error_message: result.error
    });
    res.status(result.success ? 200 : 404).json(result);
  });
  app.post("/api/v1/orders/:id/cancel", handleV1Auth, async (req, res) => {
    const reseller = req.reseller;
    const result = await cancelResellerOrder(reseller.user_id, req.params.id);
    const latency = Date.now() - (req.apiStartTime || Date.now());
    logResellerApiCall({
      reseller_id: reseller.user_id,
      reseller_email: reseller.email,
      method: req.method,
      path: req.path,
      status_code: result.success ? 200 : 400,
      latency_ms: latency,
      ip: req.ip || "127.0.0.1",
      error_message: result.error
    });
    res.status(result.success ? 200 : 400).json(result);
  });
  app.get("/api/v1/transactions", handleV1Auth, (req, res) => {
    const reseller = req.reseller;
    const list = getResellerOrdersList(reseller.user_id, void 0, void 0, 100);
    const transactions = list.orders.map((o) => ({
      id: o.id,
      order_reference: o.order_reference,
      category: o.category,
      product_name: o.product_name,
      amount: o.amount,
      currency: o.currency,
      balance_before: o.balance_before,
      balance_after: o.balance_after,
      status: o.status,
      created_at: o.created_at
    }));
    res.json({
      success: true,
      transactions,
      count: transactions.length
    });
  });
  app.get("/api/v1/webhooks", handleV1Auth, (req, res) => {
    const reseller = req.reseller;
    res.json({
      success: true,
      webhook_url: reseller.webhook_url || null,
      webhook_enabled: Boolean(reseller.webhook_enabled),
      webhook_last_status: reseller.webhook_last_status || null,
      webhook_last_error: reseller.webhook_last_error || null,
      webhook_last_dispatched_at: reseller.webhook_last_dispatched_at || null
    });
  });
  app.post("/api/v1/webhooks", handleV1Auth, (req, res) => {
    const reseller = req.reseller;
    const { webhook_url } = req.body || {};
    const result = updateResellerWebhookConfig(reseller.user_id, webhook_url);
    res.status(result.success ? 200 : 400).json(result);
  });
  app.delete("/api/v1/webhooks", handleV1Auth, (req, res) => {
    const reseller = req.reseller;
    updateResellerWebhookConfig(reseller.user_id, null);
    res.json({ success: true, message: "Webhook endpoint removed." });
  });
  app.post("/api/v1/webhooks/test", handleV1Auth, async (req, res) => {
    const reseller = req.reseller;
    const result = await dispatchWebhookEvent(reseller.user_id, "test.ping", {
      message: "Surest Plug Webhook verification ping is successful!",
      timestamp: (/* @__PURE__ */ new Date()).toISOString()
    });
    res.status(result.success ? 200 : 400).json(result);
  });
  app.get("/api/reseller/profile", (req, res) => {
    const { userId, email, fullName, balance } = req.query;
    if (!userId) {
      return res.status(400).json({ success: false, error: "User ID is required." });
    }
    const profile = getOrCreateResellerProfile(
      userId,
      email || "",
      fullName || "",
      parseFloat(balance) || 0
    );
    res.json({ success: true, profile });
  });
  app.post("/api/reseller/keys/generate", (req, res) => {
    const { userId, email, fullName, balance } = req.body || {};
    if (!userId) {
      return res.status(400).json({ success: false, error: "User ID is required." });
    }
    const result = generateResellerKey(
      userId,
      email || "",
      fullName || "",
      parseFloat(balance) || 0
    );
    res.status(result.success ? 200 : 400).json(result);
  });
  app.post("/api/reseller/keys/revoke", (req, res) => {
    const { userId } = req.body || {};
    if (!userId) {
      return res.status(400).json({ success: false, error: "User ID is required." });
    }
    const result = revokeResellerKey(userId);
    res.json(result);
  });
  app.post("/api/reseller/webhook", (req, res) => {
    const { userId, webhookUrl } = req.body || {};
    if (!userId) {
      return res.status(400).json({ success: false, error: "User ID is required." });
    }
    const result = updateResellerWebhookConfig(userId, webhookUrl);
    res.status(result.success ? 200 : 400).json(result);
  });
  app.post("/api/reseller/webhook/test", async (req, res) => {
    const { userId } = req.body || {};
    if (!userId) {
      return res.status(400).json({ success: false, error: "User ID is required." });
    }
    const result = await dispatchWebhookEvent(userId, "test.ping", {
      message: "Surest Plug Webhook verification ping successful!",
      timestamp: (/* @__PURE__ */ new Date()).toISOString()
    });
    res.status(result.success ? 200 : 400).json(result);
  });
  app.post("/api/reseller/wallet/sync", (req, res) => {
    const { userId, balance } = req.body || {};
    if (!userId || typeof balance !== "number") {
      return res.status(400).json({ success: false, error: "Valid userId and numeric balance are required." });
    }
    const result = syncResellerWalletBalance(userId, balance);
    res.json(result);
  });
  app.get("/api/reseller/logs", (req, res) => {
    const { userId, limit } = req.query;
    if (!userId) {
      return res.status(400).json({ success: false, error: "User ID is required." });
    }
    const logs = getResellerApiLogs(userId, Number(limit) || 30);
    res.json({ success: true, logs });
  });
  app.get("/api/reseller/orders", (req, res) => {
    const { userId, category, status, limit } = req.query;
    if (!userId) {
      return res.status(400).json({ success: false, error: "User ID is required." });
    }
    const list = getResellerOrdersList(
      userId,
      category,
      status,
      Number(limit) || 50
    );
    res.json(list);
  });
  app.get("/api/admin/resellers", (req, res) => {
    const data = getAllResellersForAdmin();
    res.json({ success: true, ...data });
  });
  app.post("/api/admin/resellers/toggle-status", (req, res) => {
    const { userId, status } = req.body || {};
    const result = adminToggleResellerStatus(userId, status);
    res.status(result.success ? 200 : 400).json(result);
  });
  app.post("/api/admin/resellers/revoke-key", (req, res) => {
    const { userId } = req.body || {};
    const result = adminRevokeResellerKey(userId);
    res.json(result);
  });
  app.get("/api/admin/resellers/logs", (req, res) => {
    const { limit, status } = req.query;
    const logs = getAdminSystemLogs(Number(limit) || 100, status);
    res.json({ success: true, logs });
  });
  app.get("/api/admin/resellers/pricing", (req, res) => {
    res.json({ success: true, pricing: getResellerPricing() });
  });
  app.post("/api/admin/resellers/pricing", (req, res) => {
    const updated = updateResellerPricing(req.body || {});
    res.json({ success: true, pricing: updated });
  });
  app.all("/api/*", (req, res) => {
    res.status(404).json({
      success: false,
      code: "NOT_FOUND",
      error: `API route ${req.method} ${req.path} not found.`
    });
  });
  if (process.env.NODE_ENV !== "production") {
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    const distPath = import_path3.default.resolve(process.cwd(), "dist");
    const indexPath = import_path3.default.join(distPath, "index.html");
    app.use(import_express.default.static(distPath));
    app.get("*", (req, res) => {
      if (import_fs3.default.existsSync(indexPath)) {
        res.sendFile(indexPath);
      } else {
        res.status(200).send("Surest Plug Digital Marketplace server is running.");
      }
    });
  }
  const server = app.listen(PORT, "0.0.0.0", () => {
    console.log(`[Cloud Run / Production] Surest Plug Server successfully listening on 0.0.0.0:${PORT} (PID: ${process.pid})`);
    startIntlExpiryWorker(5e3);
  });
  server.on("error", (err) => {
    console.error(`[Server Error] Failed to listen on 0.0.0.0:${PORT}:`, err);
  });
}
startServer().catch((err) => {
  console.error("Failed to start Surest Plug Server:", err);
  process.exit(1);
});
//# sourceMappingURL=server.cjs.map
