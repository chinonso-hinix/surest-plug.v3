<?php
/**
 * Surest Plug - InfinityFree Server Configuration Template
 *
 * Copy this file to:
 *   config/server_config.php
 *
 * Then replace the placeholder values with your real production
 * credentials on the server only.
 *
 * NEVER commit config/server_config.php to GitHub.
 */

return [
    'PAYSTACK_SECRET_KEY' => 'sk_test_29c1e4fdd198a44aae03c9b39d730e327c3269f6',
    'VITE_PAYSTACK_PUBLIC_KEY' => 'pk_test_8f6c741065f0a24206f621e4159eef97e4bd2156',

    'CARTLOGS_API_KEY' => 'REPLACE_WITH_CARTLOGS_API_KEY',

    'FOLLOWSPANEL_API_KEY' => 'REPLACE_WITH_FOLLOWSPANEL_API_KEY',

    'INSTANTNUM_API_KEY' => 'pk_live_ff5939d5488b6eefeae3ab4ddf56b93c338d58ef6ba2b066',
    'INSTANTNUM_BASE_URL' => 'https://instantnums.com/v1',
    'INSTANTNUM_USD_TO_NGN_RATE' => 1600.00,
    'INSTANTNUM_MARKUP_BELOW_1000_NGN' => 1000,
    'INSTANTNUM_MARKUP_1000_AND_ABOVE_NGN' => 2000,

    'GOOGLE_CLIENT_ID' => 'REPLACE_WITH_GOOGLE_CLIENT_ID',
    'GOOGLE_CLIENT_SECRET' => 'REPLACE_WITH_GOOGLE_CLIENT_SECRET',
];
