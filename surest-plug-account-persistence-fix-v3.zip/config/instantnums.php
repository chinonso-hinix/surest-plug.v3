<?php
/**
 * Surest Plug - InstantNums SMS Verification API Configuration
 * Production Connector for InfinityFree / cPanel / Shared Hosting
 *
 * Provider: https://instantnums.com/v1
 *
 * CRITICAL SECURITY DIRECTIVES:
 * 1. This file lives strictly on the server-side.
 * 2. INSTANTNUMS_API_KEY is NEVER exposed to browser, JS, HTML, network responses, or client storage.
 * 3. Never allow clients to pass or override the API key.
 * 4. Raw PHP warnings, stack traces, and filesystem paths are completely suppressed.
 */

// Suppress raw error output to prevent leaking internal paths or secrets
ini_set('display_errors', '0');
error_reporting(0);

// Base API URL for InstantNums v1
if (!defined('INSTANTNUMS_BASE_URL')) {
    $rawBaseUrl = trim(getenv('INSTANTNUM_BASE_URL') ?: (getenv('INSTANTNUMS_BASE_URL') ?: 'https://instantnums.com/v1'));
    if (!empty($rawBaseUrl)) {
        $rawBaseUrl = trim($rawBaseUrl, "\"'");
        if (!preg_match('/^https?:\/\//i', $rawBaseUrl)) {
            $rawBaseUrl = 'https://' . $rawBaseUrl;
        }
        $rawBaseUrl = rtrim($rawBaseUrl, '/');
        if (!preg_match('/\/v1$/i', $rawBaseUrl)) {
            $rawBaseUrl .= '/v1';
        }
    } else {
        $rawBaseUrl = 'https://instantnums.com/v1';
    }
    define('INSTANTNUMS_BASE_URL', $rawBaseUrl);
}

// Server-side API key placeholder
// Set in server environment variables or replace securely on your InfinityFree/cPanel server.
if (!defined('INSTANTNUMS_API_KEY')) {
    $rawKey = trim(getenv('INSTANTNUM_API_KEY') ?: (getenv('INSTANTNUMS_API_KEY') ?: 'INSTANTNUMS_API_KEY'));
    $rawKey = trim($rawKey, "\"'");
    define('INSTANTNUMS_API_KEY', $rawKey);
}

// Configurable USD to NGN exchange rate architecture
// Can be customized from admin settings or environment variables
if (!defined('INSTANTNUMS_USD_TO_NGN_RATE')) {
    $envRate = getenv('INSTANTNUMS_USD_TO_NGN_RATE');
    define('INSTANTNUMS_USD_TO_NGN_RATE', $envRate ? (float)$envRate : 1600.00);
}

// Configurable tier markup for supplier price BELOW ₦1,000 (default: ₦1,000)
if (!defined('INSTANTNUMS_MARKUP_BELOW_1000_NGN')) {
    $envMarkupBelow = getenv('INSTANTNUMS_MARKUP_BELOW_1000_NGN');
    define('INSTANTNUMS_MARKUP_BELOW_1000_NGN', $envMarkupBelow ? (float)$envMarkupBelow : 1000.00);
}

// Configurable tier markup for supplier price ₦1,000 OR ABOVE (default: ₦2,000)
if (!defined('INSTANTNUMS_MARKUP_1000_AND_ABOVE_NGN')) {
    $envMarkupAbove = getenv('INSTANTNUMS_MARKUP_1000_AND_ABOVE_NGN');
    define('INSTANTNUMS_MARKUP_1000_AND_ABOVE_NGN', $envMarkupAbove ? (float)$envMarkupAbove : 2000.00);
}

/**
 * Calculate retail customer price in NGN from supplier USD wholesale cost
 *
 * Pricing Rule:
 * - If supplier price < ₦1,000, add ₦1,000 (INSTANTNUMS_MARKUP_BELOW_1000_NGN).
 * - If supplier price >= ₦1,000, add ₦2,000 (INSTANTNUMS_MARKUP_1000_AND_ABOVE_NGN).
 *
 * @param float $costUsd Supplier wholesale cost in USD
 * @param float|null $customRate Optional custom exchange rate
 * @param float|null $customMarkupBelow Optional custom markup for < ₦1,000
 * @param float|null $customMarkupAbove Optional custom markup for >= ₦1,000
 * @return array
 */
function instantnums_calculate_retail_price(
    float $costUsd,
    ?float $customRate = null,
    ?float $customMarkupBelow = null,
    ?float $customMarkupAbove = null
): array {
    $rate = $customRate !== null && $customRate > 0 ? $customRate : INSTANTNUMS_USD_TO_NGN_RATE;
    $markupBelow = $customMarkupBelow !== null && $customMarkupBelow >= 0 ? $customMarkupBelow : INSTANTNUMS_MARKUP_BELOW_1000_NGN;
    $markupAbove = $customMarkupAbove !== null && $customMarkupAbove >= 0 ? $customMarkupAbove : INSTANTNUMS_MARKUP_1000_AND_ABOVE_NGN;

    // Convert wholesale USD to NGN
    $supplierCostNgn = round($costUsd * $rate, 2);

    // Tiered pricing:
    // If supplier price is BELOW ₦1,000, add ₦1,000
    // If supplier price is ₦1,000 OR ABOVE, add ₦2,000
    $markup = ($supplierCostNgn < 1000.00) ? $markupBelow : $markupAbove;

    $customerPriceNgn = round($supplierCostNgn + $markup, 2);

    return [
        'cost_usd' => $costUsd,
        'rate' => $rate,
        'supplier_cost_ngn' => $supplierCostNgn,
        'customer_price' => $customerPriceNgn,
        'profit_ngn' => $markup
    ];
}

/**
 * Execute a secure server-to-server request to InstantNums API
 *
 * @param string $endpoint Relative path e.g. '/balance', '/services'
 * @param string $method 'GET' or 'POST'
 * @param array $payload Request body for POST requests or query params for GET
 * @return array Sanitized response array
 */
function instantnums_request(string $endpoint, string $method = 'GET', array $payload = []): array {
    $apiKey = INSTANTNUMS_API_KEY;

    // Fail safe if placeholder or empty
    if (empty($apiKey) || $apiKey === 'INSTANTNUMS_API_KEY') {
        return [
            'success' => false,
            'error_code' => 'API_KEY_NOT_CONFIGURED',
            'error' => 'Instant numbers service is not yet configured with an API key. Please configure the provider key in server settings.'
        ];
    }

    // Sanitize endpoint to prevent URL manipulation or arbitrary external targets
    $cleanEndpoint = '/' . ltrim($endpoint, '/');
    $url = INSTANTNUMS_BASE_URL . $cleanEndpoint;

    $method = strtoupper($method);
    if ($method === 'GET' && !empty($payload)) {
        $url .= (strpos($url, '?') === false ? '?' : '&') . http_build_query($payload);
    }

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
    curl_setopt($ch, CURLOPT_TIMEOUT, 18);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 8);
    curl_setopt($ch, CURLOPT_USERAGENT, 'SurestPlug-InstantNums-Proxy/1.0');

    $headers = [
        'Authorization: Bearer ' . $apiKey,
        'Accept: application/json'
    ];

    if ($method === 'POST') {
        curl_setopt($ch, CURLOPT_POST, true);
        $jsonPayload = json_encode($payload);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonPayload);
        $headers[] = 'Content-Type: application/json';
        $headers[] = 'Content-Length: ' . strlen($jsonPayload);
    }

    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlError = curl_error($ch);
    curl_close($ch);

    // Network / cURL failures
    if ($curlError) {
        return [
            'success' => false,
            'error_code' => 'NETWORK_TIMEOUT',
            'error' => 'Unable to reach international numbers provider. Please try again shortly.'
        ];
    }

    // Decode JSON safely
    $decoded = json_decode($response, true);
    if ($decoded === null && !empty($response)) {
        return [
            'success' => false,
            'error_code' => 'INVALID_PROVIDER_RESPONSE',
            'error' => 'Invalid response format from verification provider.'
        ];
    }

    // Handle standard HTTP status codes with customer-safe messages
    switch ($httpCode) {
        case 200:
        case 201:
            // Check success flag from InstantNums (returns { success: 1, ... })
            if (is_array($decoded)) {
                $isSuccess = isset($decoded['success']) ? (int)$decoded['success'] === 1 : true;
                if ($isSuccess) {
                    return [
                        'success' => true,
                        'data' => $decoded
                    ];
                }
                return [
                    'success' => false,
                    'error_code' => 'PROVIDER_REJECTED',
                    'error' => $decoded['message'] ?? $decoded['error'] ?? 'The requested number service is currently unavailable.'
                ];
            }
            return [
                'success' => false,
                'error' => 'Unexpected response from number provider.'
            ];

        case 400:
            return [
                'success' => false,
                'error_code' => 'BAD_REQUEST',
                'error' => $decoded['message'] ?? $decoded['error'] ?? 'Invalid request parameters for number service.'
            ];

        case 401:
            // Never leak API key credentials
            return [
                'success' => false,
                'error_code' => 'AUTHENTICATION_FAILED',
                'error' => 'International number service authentication failed. Please contact administrator.'
            ];

        case 402:
            return [
                'success' => false,
                'error_code' => 'SUPPLIER_LOW_BALANCE',
                'error' => 'Verification numbers are temporarily out of stock. Please check back shortly.'
            ];

        case 404:
            return [
                'success' => false,
                'error_code' => 'NOT_FOUND',
                'error' => $decoded['message'] ?? $decoded['error'] ?? 'Requested service, country, or order was not found.'
            ];

        case 429:
            return [
                'success' => false,
                'error_code' => 'RATE_LIMIT_EXCEEDED',
                'error' => 'Rate limit exceeded. Please wait a few moments before trying again.'
            ];

        case 500:
        case 502:
        case 503:
        case 504:
        default:
            return [
                'success' => false,
                'error_code' => 'PROVIDER_UNAVAILABLE',
                'error' => 'International number provider is temporarily unavailable. Please try again shortly.'
            ];
    }
}

/**
 * Retrieve supplier balance (Admin only)
 * GET https://instantnums.com/v1/balance
 */
function instantnums_get_balance(): array {
    $res = instantnums_request('/balance', 'GET');
    if (!$res['success']) {
        return $res;
    }
    $data = $res['data'];
    $rawUsd = isset($data['balance_usd']) ? (float)$data['balance_usd'] : 0.0;
    $rawNgn = isset($data['balance_ngn']) ? (float)$data['balance_ngn'] : 0.0;
    $rate = INSTANTNUMS_USD_TO_NGN_RATE > 0 ? (float)INSTANTNUMS_USD_TO_NGN_RATE : 1600.0;
    $ngnInUsd = $rawNgn > 0 ? ($rawNgn / $rate) : 0.0;
    $totalUsd = round($rawUsd + $ngnInUsd, 2);
    $totalNgn = round($totalUsd * $rate, 2);

    return [
        'success' => true,
        'balance_usd' => $totalUsd,
        'balance_ngn' => $totalNgn,
        'balanceUsd' => $totalUsd,
        'balanceNgn' => $totalNgn,
        'exchangeRate' => $rate,
        'currency' => $data['currency'] ?? 'USD',
        'rate' => $rate,
        'wallets' => [
            'usd' => $rawUsd,
            'ngn' => $rawNgn
        ]
    ];
}

/**
 * Retrieve supported countries list
 * GET https://instantnums.com/v1/countries
 */
function instantnums_get_countries(): array {
    $res = instantnums_request('/countries', 'GET');
    if (!$res['success']) {
        return $res;
    }
    $list = $res['data']['countries'] ?? (is_array($res['data']) && !isset($res['data']['success']) ? $res['data'] : []);
    return [
        'success' => true,
        'countries' => $list,
        'data' => $list
    ];
}

/**
 * Retrieve supported services list
 * GET https://instantnums.com/v1/services
 */
function instantnums_get_services(): array {
    $res = instantnums_request('/services', 'GET');
    if (!$res['success']) {
        return $res;
    }
    $list = $res['data']['services'] ?? (is_array($res['data']) && !isset($res['data']['success']) ? $res['data'] : []);
    return [
        'success' => true,
        'services' => $list,
        'data' => $list
    ];
}

/**
 * Retrieve wholesale price for a specific service and country and calculate retail price
 * GET https://instantnums.com/v1/price?service=SERVICE_ID&country=COUNTRY_ID
 */
function instantnums_get_price(string $serviceId, string $countryId): array {
    $res = instantnums_request('/price', 'GET', [
        'service' => $serviceId,
        'country' => $countryId
    ]);
    if (!$res['success']) {
        return $res;
    }

    $data = $res['data'];
    $costUsd = isset($data['price_usd']) ? (float)$data['price_usd'] : 0.0;
    $pricing = instantnums_calculate_retail_price($costUsd);

    $payload = [
        'service' => (string)($data['service'] ?? $serviceId),
        'country' => (string)($data['country'] ?? $countryId),
        'cost_usd' => $pricing['cost_usd'],
        'price_ngn' => $pricing['customer_price'],
        'supplier_cost_ngn' => $pricing['supplier_cost_ngn'],
        'currency' => 'NGN'
    ];

    return [
        'success' => true,
        'data' => $payload,
        'service' => $payload['service'],
        'country' => $payload['country'],
        'cost_usd' => $payload['cost_usd'],
        'price_ngn' => $payload['price_ngn'],
        'supplier_cost_ngn' => $payload['supplier_cost_ngn'],
        'currency' => 'NGN'
    ];
}

/**
 * Retrieve stock for a specific service and country
 * GET https://instantnums.com/v1/stock?service=SERVICE_ID&country=COUNTRY_ID
 */
function instantnums_get_stock(string $serviceId, string $countryId): array {
    $res = instantnums_request('/stock', 'GET', [
        'service' => $serviceId,
        'country' => $countryId
    ]);
    if (!$res['success']) {
        return $res;
    }

    $data = $res['data'];
    $available = isset($data['available']) ? (int)$data['available'] : 
                 (isset($data['stock']) ? (int)$data['stock'] : 
                 (isset($data['count']) ? (int)$data['count'] : 
                 (isset($data['quantity']) ? (int)$data['quantity'] : 0)));

    $payload = [
        'service' => (string)($data['service'] ?? $serviceId),
        'country' => (string)($data['country'] ?? $countryId),
        'available' => $available,
        'is_in_stock' => $available > 0
    ];

    return [
        'success' => true,
        'data' => $payload,
        'service' => $payload['service'],
        'country' => $payload['country'],
        'available' => $available,
        'is_in_stock' => $available > 0
    ];
}

/**
 * Purchase/Reserve an SMS verification number
 * POST https://instantnums.com/v1/sms/purchase
 * Body: { "service": "22", "country": "1" }
 */
function instantnums_purchase_sms(string $serviceId, string $countryId): array {
    $res = instantnums_request('/sms/purchase', 'POST', [
        'service' => $serviceId,
        'country' => $countryId
    ]);
    if (!$res['success']) {
        return $res;
    }

    $data = $res['data'];
    $costUsd = isset($data['cost_usd']) ? (float)$data['cost_usd'] : 0.0;
    $pricing = instantnums_calculate_retail_price($costUsd);

    return [
        'success' => true,
        'order_id' => (string)($data['order_id'] ?? ''),
        'phone_number' => (string)($data['phone_number'] ?? ''),
        'cost_usd' => $costUsd,
        'customer_price' => $pricing['customer_price'],
        'supplier_cost_ngn' => $pricing['supplier_cost_ngn'],
        'profit_ngn' => $pricing['profit_ngn'],
        'currency' => 'NGN',
        'expires_at' => $data['expires_at'] ?? null,
        'status' => $data['status'] ?? 'waiting'
    ];
}

/**
 * Poll status of SMS verification order / retrieve incoming OTP
 * GET https://instantnums.com/v1/sms/{order_id}
 */
function instantnums_get_sms_status(string $orderId): array {
    $cleanOrderId = urlencode($orderId);
    $res = instantnums_request('/sms/' . $cleanOrderId, 'GET');
    if (!$res['success']) {
        return $res;
    }

    $data = $res['data'];
    $rawStatus = isset($data['status']) ? strtolower(trim((string)$data['status'])) : 'waiting';
    $rawSms = isset($data['sms']) ? trim((string)$data['sms']) : null;
    $rawFullSms = isset($data['full_sms']) ? trim((string)$data['full_sms']) : null;

    // Filter placeholder values like "None", "null", etc.
    $forbidden = ['none', 'null', 'undefined', 'n/a', 'na', 'false', '0', '---'];
    $sms = ($rawSms !== null && !in_array(strtolower($rawSms), $forbidden, true)) ? $rawSms : null;
    $fullSms = ($rawFullSms !== null && !in_array(strtolower($rawFullSms), $forbidden, true)) ? htmlspecialchars($rawFullSms, ENT_QUOTES, 'UTF-8') : null;

    // Normalized status
    $normalizedStatus = 'waiting';
    if ($rawStatus === 'cancelled' || $rawStatus === 'canceled') {
        $normalizedStatus = 'cancelled';
    } elseif ($rawStatus === 'refunded') {
        $normalizedStatus = 'refunded';
    } elseif ($rawStatus === 'expired' || $rawStatus === 'timeout') {
        $normalizedStatus = 'expired';
    } elseif ($sms !== null || in_array($rawStatus, ['received', 'code_received', 'sms_received'], true)) {
        $normalizedStatus = 'received';
    } elseif (in_array($rawStatus, ['finished', 'completed'], true)) {
        $normalizedStatus = 'completed';
    }

    $isTerminal = in_array($normalizedStatus, ['completed', 'cancelled', 'refunded', 'expired'], true);

    return [
        'success' => true,
        'order_id' => (string)($data['order_id'] ?? $orderId),
        'provider_status' => $rawStatus,
        'normalized_status' => $normalizedStatus,
        'status' => $normalizedStatus,
        'is_terminal' => $isTerminal,
        'sms' => $sms,
        'full_sms' => $fullSms
    ];
}

/**
 * Cancel an active SMS verification number order and obtain refund
 * POST https://instantnums.com/v1/sms/{order_id}/cancel
 */
function instantnums_cancel_sms(string $orderId): array {
    $cleanOrderId = urlencode($orderId);
    $res = instantnums_request('/sms/' . $cleanOrderId . '/cancel', 'POST', []);
    if (!$res['success']) {
        return $res;
    }

    $data = $res['data'];
    $refundedUsd = isset($data['refunded_amount']) ? (float)$data['refunded_amount'] : 0.0;
    $refundedNgn = round($refundedUsd * INSTANTNUMS_USD_TO_NGN_RATE, 2);

    return [
        'success' => true,
        'order_id' => (string)($data['order_id'] ?? $orderId),
        'status' => (string)($data['status'] ?? 'cancelled'),
        'refunded_amount_usd' => $refundedUsd,
        'refunded_amount_ngn' => $refundedNgn,
        'currency' => $data['currency'] ?? 'USD'
    ];
}
